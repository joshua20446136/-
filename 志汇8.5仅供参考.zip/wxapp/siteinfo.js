module.exports = {
  name: "QQ：576369389",
    uniacid: "6",
    acid: "6",
    multiid: "0",
    version: "1.0",
    siteroot: "https://888.xcx888.top/app/index.php",
    design_method: "3"
};