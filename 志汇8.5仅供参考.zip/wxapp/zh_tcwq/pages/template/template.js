var app = getApp();

Page({
    data: {
        a: "asdadasdad"
    },
    onLoad: function() {
        this.setData({
            a: "aaaaaaaaa"
        });
    }
});