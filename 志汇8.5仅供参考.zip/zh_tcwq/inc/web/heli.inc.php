<?php
$GLOBALS['frames'] = $this->getMainMenu();
include $this->template('web/heli');