<?php
define("HOST","localhost");  
define("DB_NAME","jos787uic");  
define("USER","jos787uic");  
define("PASS","jos787uic123");
?>