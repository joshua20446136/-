<?php
defined('IN_IA') or die('Access Denied');
require IA_ROOT . '/addons/yc_youliao/class/defineData.php';
require IA_ROOT . '/addons/yc_youliao/class/func.php';
require IA_ROOT . '/addons/yc_youliao/class/autoLoad.php';
require IA_ROOT . '/addons/yc_youliao/class/util.php';
require IA_ROOT . '/addons/yc_youliao/class/commonGetData.php';
require IA_ROOT . '/addons/yc_youliao/model/Admin.php';
class yc_youliaoModule extends WeModule
{
	public function settingsDisplay($settings)
	{
		global $_GPC, $_W;
		$res = Admin::checkAdminType("1");
		if (!$res) {
			message('很抱歉，您没有此项功能权限', '', 'success');
		}
		$title = '社区设置';
		clear_cook();
		$op = !empty($_GPC['op']) ? $_GPC['op'] : 'display';
		$timelist = pdo_fetchall('SELECT * FROM ' . tablename(MSTIME) . " WHERE uniacid = {$_W['uniacid']} ORDER BY timestart ASC ");
		$word = commonGetData::sensitiveword();
		$contractData = commonGetData::sensitiveword(1);
		if (checksubmit()) {
			$sensitiveword = $_GPC['sensitiveword'];
			$replace = $_GPC['replace'];
			if (!empty($sensitiveword) && empty($word)) {
				pdo_insert(WORD, array('sensitiveword' => $sensitiveword, 'replace' => $replace, 'uniacid' => $_W['uniacid']));
			} else {
				if (!empty($sensitiveword) && !empty($word)) {
					pdo_update(WORD, array('sensitiveword' => $sensitiveword, 'replace' => $replace), array('word_id' => $word['word_id'], 'uniacid' => $_W['uniacid']));
				}
			}
			$contract = htmlspecialchars_decode($_GPC['contract']);
			if (!empty($contract) && empty($contractData)) {
				pdo_insert(WORD, array('contract' => $contract, 'type' => 1, 'uniacid' => $_W['uniacid']));
			} else {
				if (!empty($contract) && !empty($contractData)) {
					pdo_update(WORD, array('contract' => $contract), array('word_id' => $contractData['word_id'], 'type' => 1, 'uniacid' => $_W['uniacid']));
				}
			}
			$cfg = array('wx' => $_GPC['wx'], 'isautorefundgroup' => trim($_GPC['isautorefundgroup']), 'isreturncredit' => trim($_GPC['isreturncredit']), 'autocancelordertime' => $_GPC['autocancelordertime'], 'remindmessagetime' => $_GPC['remindmessagetime'], 'qrcode_flag' => intval($_GPC['qrcode_flag']), 'help' => htmlspecialchars_decode($_GPC['help']), 'index_title' => $_GPC['index_title'], 'footer' => htmlspecialchars_decode($_GPC['footer']), 'comment_flag' => $_GPC['comment_flag'], 'disclaimer' => htmlspecialchars_decode($_GPC['disclaimer']), 'time_long' => $_GPC['time_long'], 'qrcode_flag' => intval($_GPC['qrcode_flag']), 'qr_code' => $_GPC['qr_code'], 'share_title' => trim($_GPC['share_title']), 'share_img' => $_GPC['share_img'], 'share_info' => $_GPC['share_info'], 'qiandao_random' => $_GPC['qiandao_random'], 'qiandao_jifen' => trim($_GPC['qiandao_jifen']), 'credit2money' => $_GPC['credit2money'], 'showShop' => $_GPC['showShop'], 'showChannel' => $_GPC['showChannel'], 'showChannelNum' => $_GPC['showChannelNum'], 'istplon' => $_GPC['istplon'], 'kefutplminute' => $_GPC['kefutplminute'], 'views_start' => intval($_GPC['views_start']), 'user_views' => intval($_GPC['user_views']), 'shop_views' => intval($_GPC['shop_views']), 'animation_list' => intval($_GPC['animation_list']), 'red_num' => $_GPC['red_num'], 'ring_creidit' => $_GPC['ring_creidit'], 'ring_num' => $_GPC['ring_num'], 'mapak' => $_GPC['mapak'], 'show_service' => intval($_GPC['show_service']), 'service_btn' => $_GPC['service_btn'], 'service_link' => $_GPC['service_link'], 'service_w' => $_GPC['service_w'], 'service_h' => $_GPC['service_h'], 'service_b' => $_GPC['service_b'], 'service_l' => $_GPC['service_l'], 'issamecity' => intval($_GPC['issamecity']), 'switch_base' => intval($_GPC['switch_base']), 'isredpacket' => intval($_GPC['isredpacket']), 'isshang' => intval($_GPC['isshang']), 'redMsg' => intval($_GPC['redMsg']), 'redMsg_num' => intval($_GPC['redMsg_num']), 'redMsgUser' => intval($_GPC['redMsgUser']), 'transfer_min' => $_GPC['transfer_min'], 'transfer_max' => $_GPC['transfer_max'], 'transfer_user' => $_GPC['transfer_user'], 'pay_type_user' => $_GPC['pay_type_user'], 'views_num' => $_GPC['views_num'], 'showWater' => intval($_GPC['showWater']), 'shop_service_btn' => $_GPC['shop_service_btn'], 'shop_logo' => $_GPC['shop_logo'], 'shop_bgpic' => $_GPC['shop_bgpic'], 'in_money' => $_GPC['in_money'], 'index_money' => $_GPC['index_money'], 'time_money' => $_GPC['time_money'], 'group_money' => $_GPC['group_money'], 'shop_enter' => intval($_GPC['shop_enter']), 'shop_pay_type' => $_GPC['shop_pay_type'], 'transfer' => $_GPC['transfer'], 'shop_transfer_min' => $_GPC['shop_transfer_min'], 'shop_transfer_max' => $_GPC['shop_transfer_max'], 'shop_enter_price' => intval($_GPC['shop_enter_price']), 'one_year_money' => $_GPC['one_year_money'], 'two_year_money' => $_GPC['two_year_money'], 'three_year_money' => $_GPC['three_year_money'], 'one_renew' => $_GPC['one_renew'], 'two_renew' => $_GPC['two_renew'], 'three_renew' => $_GPC['three_renew'], 'refundtime' => $_GPC['refundtime'], 'free_month' => intval($_GPC['free_month']), 'btn1_name' => trim($_GPC['btn1_name']), 'btn1_link' => trim($_GPC['btn1_link']), 'btn1' => $_GPC['btn1'], 'btn1_hover' => $_GPC['btn1_hover'], 'btn2_name' => trim($_GPC['btn2_name']), 'btn2_link' => trim($_GPC['btn2_link']), 'btn2' => $_GPC['btn2'], 'btn2_hover' => $_GPC['btn2_hover'], 'btn3_name' => trim($_GPC['btn3_name']), 'btn3_link' => trim($_GPC['btn3_link']), 'btn3' => $_GPC['btn3'], 'btn3_hover' => $_GPC['btn3_hover'], 'btn4_name' => trim($_GPC['btn4_name']), 'btn4_link' => trim($_GPC['btn4_link']), 'btn4' => $_GPC['btn4'], 'btn4_hover' => $_GPC['btn4_hover'], 'btn5_name' => trim($_GPC['btn5_name']), 'btn5_link' => trim($_GPC['btn5_link']), 'btn5' => $_GPC['btn5'], 'btn5_hover' => $_GPC['btn5_hover'], 'islanniu_hsyunfu' => intval($_GPC['islanniu_hsyunfu']), 'lanniu_hsyunfu_title' => $_GPC['lanniu_hsyunfu_title'], 'lanniu_hsyunfu_des' => $_GPC['lanniu_hsyunfu_des'], 'lanniu_hsyunfu_logo' => trim($_GPC['lanniu_hsyunfu_logo']), 'wxapp_type' => intval($_GPC['wxapp_type']));
			if ($this->saveSettings($cfg)) {
				$this->message("保存成功", '', "success");
			} else {
				$this->message("保存失败", '', "error");
			}
		}
		include $this->template("web/setting");
		die;
	}
	public function message($msg, $url, $status)
	{
		$template = 'web/message';
		include $this->template($template);
		die;
	}
}