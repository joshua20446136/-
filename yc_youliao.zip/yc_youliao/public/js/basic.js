require.config({
    urlArgs: "v=" +  (new Date()).getTime(), //getHours
    paths: {
        'weixinJs':  '/addons/yc_youliao/public/js/weixinJs',
        'common':  '/addons/yc_youliao/public/js/common'

    },

});
 function createWebUrl(dostr,opstr,obj){
    var str = '&do='+dostr+'&op='+opstr;
    for(t in obj){
        str += '&'+t+'='+obj[t];
    }
    return window.sysinfo.siteroot+'web/index.php?i='+window.sysinfo.uniacid+'&c=site&a=entry'+str+'&m=yc_youliao';
}
function createAppUrl(dostr,opstr,obj){
    var str = '&do='+dostr+'&op='+opstr;
    for(t in obj){
        str += '&'+t+'='+obj[t];
    }
    return window.sysinfo.siteroot+'app/index.php?i='+window.sysinfo.uniacid+'&c=entry'+str+'&m=yc_youliao';
}

function clearNoNum(obj){
    //修复第一个字符是小数点 的情况.
    if(obj.value !=''&& obj.value.substr(0,1) == '.'){
        obj.value="";
    }

    obj.value = obj.value.replace(/[^\d.]/g,"");  //清除“数字”和“.”以外的字符
    obj.value = obj.value.replace(/\.{2,}/g,"."); //只保留第一个. 清除多余的
    obj.value = obj.value.replace(".","$#$").replace(/\./g,"").replace("$#$",".");
    obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3');//只能输入两个小数
    if(obj.value.indexOf(".")< 0 && obj.value !=""){//以上已经过滤，此处控制的是如果没有小数点，首位不能为类似于 01、02的金额
        if(obj.value.substr(0,1) == '0' && obj.value.length == 2){
            obj.value= obj.value.substr(1,obj.value.length);
        }
    }
}
function checkphone(phone){
    var flag = false;
    var reg0 =  /^(([0\+]\d{2,3}-)?(0\d{2,3})-)?(\d{7,8})(-(\d{3,}))?$/;   //判断 固话
    var reg1 =/^((\(\d{2,3}\))|(\d{3}\-))?(13|15|18)\d{9}$/;                     //判断 手机
    if (reg0.test(phone)) flag=true;
    if (reg1.test(phone)) flag=true;
    if(!flag){
        tip("电话号码，格式不对");
        tip_close();
        return false;
    }
}
$(document).ready(function(){
        $("tr:first").addClass("trhead");//第一行
        $("tr:even").addClass("tr-2");//偶数行
    $(".orderblock").click(function() {
        $(".order-by-input").toggle();
        $(".orderblock").toggle();
    });
    $(".dis_randomopen").click(function() {
        $(".dis_random").show();
        $(".dis_other").hide();
    });
    $(".dis-zk-c").click(function() {
        $(".dis_random").hide();
        $(".dis-money").hide();
        $(".dis_other").show();
        $(".dis-zk").show();
    });
    $(".dis-money-c").click(function() {
        $(".dis_random").hide();
        $(".dis-zk").hide();
        $(".dis_other").show();
        $(".dis-money").show();
    });

    $('.add_a_inco').click(function(){
        var valueinput =  $(this).prev().find('input');
        var value = valueinput.val();
        if(value == ''){
            tip('请先在输入框输入标签名称');tip_close();return false;
        }
        var str = '<label><input type="checkbox" name="inco[]" value="'+value+'" checked="checked"> '+value+'</label>';
        $(this).parents('.input_form').find('.inco_append_box').append(str);
        valueinput.val('').focus();
    });
    $('.admintype-3').click(function(){
        $('.password').css('display','none');
    });
    $('.admintype-1').click(function(){
        $('.password').css('display','block');
    });



    });

$(".op-toggle-1").click(function() {
    $(".cotent-toggle").show();
});
$(".op-toggle-2").click(function() {
    $(".cotent-toggle").hide();

});

function returnApply(obj,shop_id,type,opt){
  var  reason='';
    if(opt==2) {
        reason = $(obj).parents('.info-list').find('.reason').val();
        var flag = $(obj).parents('.info-list').find('.flag').val();
        if (reason.length == 0 && flag == 0) {
            $('.reason-box').hide();
            $('.reason-sub').hide();
            $(obj).parents('.info-list').find('.reason-box').show();
            $(obj).parents('.info-list').find('.flag').val('1');
            return;
        } else {
            $('.reason-sub').show();
        }
    }
    var url=createWebUrl('ajax_req','check_shop_apply');
    $.ajax({
        type:'post',
        url:url,
        dataType: 'json',
        data:{'shop_id':shop_id,'opt':opt,'type':type,'reason':reason},
        success:function(data){
            tip(data.str);
            tip_close();
            if(data.status==1){
                setTimeout(function () {
                    window.location.reload();
                }, 1500);
            }



        }
    });
}

function opstatus(shop_id,op,opt){
    var url=createWebUrl('ajax_req',op);
    $.ajax({
        type:'post',
        url:url,
        dataType: 'json',
        data:{'shop_id':shop_id,'opt':opt},
        success:function(data){
            tip(data.str);
            tip_close();
            window.location.reload();

        }
    });
}
function adminstatus(admin_id,op,opt){
    var url=createWebUrl('ajax_req',op);
    $.ajax({
        type:'post',
        url:url,
        dataType: 'json',
        data:{'admin_id':admin_id,'opt':opt},
        success:function(data){
            tip(data.str);
            tip_close();
            window.location.reload();

        }
    });
}
function changeline(value1){
    $('select[name="ccate_id"]').find("option").remove();
    var op='changeline';
    var url=createWebUrl('ajax_req',op);
    fetchbyajax1(url,value1,op);
}
function changearea(value1){
    $('select[name="area_id"]').find("option").remove();
    $('select[name="business_id"]').find("option").remove();
    var op='changearea2';
    var url=createWebUrl('ajax_req',op);
    fetchbyajax2(url,value1,op);
}
function changebusiness(value1){
    $('select[name="business_id"]').find("option").remove();
    var op='changebusiness';
    var url=createWebUrl('ajax_req',op);
    fetchbyajax3(url,value1,op);
}


function copyit(){
        $('.copyurl').zclip({
            path: './resource/components/zclip/ZeroClipboard.swf',
            copy: function(){
                return $(this).attr('data-url');
            },
            afterCopy: function(){
                $('.copyurl').off();
                tip('复制成功');
                tip_close();
            }
        });



}
function randomOpen(){
    $('.qiandao_des').css('display','block');
    $('.qiandao_des').html('此处填随机签到最大整数积分');
}
function randomClose(){
    $('.qiandao_des').css('display','none');
}


function search_members() {
    $('#module-menus').show();
    if( $.trim($('#search-kwd').val())==''){
        tip('请输入关键词');
        tip_close();
        return;
    }
    $("#module-menus").html("正在搜索....")
    var url=createWebUrl('shop_admin','query');
    $.get(url, {
        keyword: $.trim($('#search-kwd').val())
    }, function(dat){
        $('#module-menus').html(dat);
    });
}
function check_account(obj,type,id){
    if(type==2){
        reason = $(obj).parents('.info-list').find('.reason').val();
        var flag = $(obj).parents('.info-list').find('.flag').val();
        if(reason.length==0 && flag==0){
            $('.reason-box').hide();
            $('.reason-sub').hide();
            $(obj).parents('.info-list').find('.reason-box').show();
            $(obj).parents('.info-list').find('.flag').val('1');
            return;
        }else{
            $('.reason-sub').show();
        }
    }
    var url=createWebUrl('ajax_req','recash');
    $.ajax({
        url: url,
        type: 'post',
        dataType: 'json',
        data: {id:id,type:type},
        success:function(data){
            if (data.status == 1) {
                if(type==1){
                    tip('提现操作成功');
                }else{
                    tip('驳回现申请操作成功');
                }
                tip_close();
                $(obj).parents('tr').remove();
            }else{
                tip(data.str);
                tip_close();
            }
        }
    });
}
function showEnterPrice(){
    $("#entermonth").hide();
    $("#enterPrice").show();
    $("#renewPrice").show();
}
function hideEnterPrice(){
    $("#entermonth").hide();
    $("#enterPrice").hide();
    $("#renewPrice").hide();
}
function renewPrice(){
    $("#renewPrice").show();
    $("#entermonth").show();
    $("#enterPrice").hide();
}

function SelectBox(options) {
    this.hasSelect = []
    this.id = options.id
    this.name = options.name
    this.init()
}
SelectBox.prototype.init = function () {
    var Box = $('<div class="m-select"></div>')
    var boxSelect = $('<div class="boxSelect">请选择</div>')
    Box.append(boxSelect)
    var str = '<div class="selectWap">'
    var _self = this
    $(this.id).children().each(function (i, v) {
        var _this = $(this)
        str += '<label for="type' + i + '" class="s-label">'
        if ( _this.data('checked') == 1) {
            str += '<input type="checkbox" name="' + _self.name + '" value="' + _this.val() + '" checked class="s-checkbox" id="type' + i + '">'
            str += '<span class="s-checkbox__inner is-checked"></span>'
            _self.hasSelect.push(_this.text())
        } else {
            str += '<input type="checkbox" name="' + _self.name + '"  value="' + _this.val() + '" class="s-checkbox" id="type' + i + '">'
            str += '<span class="s-checkbox__inner"></span>'
        }
        str += '<span class="s-text">' + _this.text() + '</span>'
        str += '</label>'
    })
    str += '</div>'
    if (_self.hasSelect.length > 0) {
        boxSelect.text(_self.hasSelect.join(' 、 '))
    }
    $(str).appendTo(Box)
    Box.on('click', '.boxSelect', function () {
        var _this = $(this)
        if (!_this.hasClass('show')) {
            _this.addClass('show')
            $('.selectWap').addClass('h180')
        } else {
            _this.removeClass('show')
            $('.selectWap').removeClass('h180')
        }
    })
    Box.on('click', '.s-checkbox', function () {
        var _this = $(this)
        if (this.checked) {
            _self.hasSelect.push(_this.siblings('.s-text').text())
            _this.siblings('.s-checkbox__inner').addClass('is-checked')
        } else {
            var index = _self.hasSelect.indexOf(_this.siblings('.s-text').text())
            _self.hasSelect.splice(index, 1)
            _this.siblings('.s-checkbox__inner').removeClass('is-checked')
        }
        if (_self.hasSelect.length > 0) {
            $('.boxSelect').text(_self.hasSelect.toString())
        } else {
            $('.boxSelect').text('请点击选择(多选)')
        }
    })
    $(this.id).replaceWith(Box)
}

function checkPassport(url){
    $('#passport').blur(function(){
        var name=$(this).val();
        var admin_id=$('#admin_id').val();
        url=url+'&name='+name+'&admin_id='+admin_id;
        $.ajax({
            type:'get',
            url:url,
            dataType: 'json',
            success:function(data){
            if(data.stauts=='1'){
                $('#tishi').text("您输入的用户名已存在，请重新输入");
            }
        }
    });
})
}