<?php
global $_GPC,$_W;
$tag = random(32);
include $this->template('web/param');
exit;