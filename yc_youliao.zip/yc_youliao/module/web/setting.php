<?php
global $_GPC,$_W;
$title='基础设置';


include $this->template('web/setting');
exit();