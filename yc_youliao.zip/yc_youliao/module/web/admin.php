<?php
global $_GPC, $_W;
$title = "管理员";
$do = $_GPC["do"];
$op = !empty($_GPC["op"]) ? $_GPC["op"] : "display";
$Admin = new Admin();
if ($op == "display") {
	if (!empty($_GPC["status"])) {
		$codition .= " and status=" . $_GPC["status"];
	}
	$list = $Admin->getAdminAll();
} else {
	if ($op == "post") {
		$admin_id = intval($_GPC["admin_id"]);
		if (!empty($admin_id)) {
			$item = $Admin::getAdminByid($admin_id);
		}
		if (checksubmit("submit")) {
			$openid = $_GPC["openid"];
			if (empty($openid)) {
				$this->message("请选择管理员", referer(), "error");
			}
			$admin = util::getSingelDataInSingleTable(ADMIN, array("passport" => $_GPC["passport"]));
			if (!empty($admin) && $admin_id == 0) {
				$this->message("很抱歉，用户名已被注册，请换一个再试！");
			}
			if (strlen($_GPC["password"]) < 8) {
				$this->message("很抱歉，您的密码长度必须要8位以上！");
			}
			$nadmin = new Admin();
			$wq_admin = $nadmin->getWqAdmin();
			$salt = rand(10000, 99999);
			$data = array("uniacid" => $_W["uniacid"], "admin_uid" => $wq_admin["uid"], "openid" => trim($_GPC["openid"]), "salt" => $salt, "password" => user_hash($_GPC["password"], $salt), "passport" => $_GPC["passport"], "avatar" => $_GPC["avatar"], "nickname" => $_GPC["nickname"], "status" => intval($_GPC["status"]), "msg_flag" => intval($_GPC["msg_flag"]), "addtime" => TIMESTAMP, "admin_name" => $_GPC["admin_name"], "mobile" => $_GPC["mobile"], "type" => serialize($_GPC["type"]));
			if ($admin_id == 0) {
				pdo_insert(ADMIN, $data);
			} else {
				pdo_update(ADMIN, $data, array("admin_id" => $admin_id, "uniacid" => $_W["uniacid"]));
			}
			$this->message("操作成功！", $this->createWebUrl("admin", array("op" => "display")), "success");
		}
	} else {
		if ($op == "delete") {
			$id = intval($_GPC["admin_id"]);
			pdo_delete(ADMIN, array("admin_id" => $id, "uniacid" => $_W["uniacid"]));
			$this->message("删除成功！", $this->createWebUrl("admin", array("op" => "display")), "success");
		} else {
			if ($op == "query") {
				$kwd = trim($_GPC["keyword"]);
				$wechatid = intval($_GPC["wechatid"]);
				if (empty($wechatid)) {
					$wechatid = $_W["uniacid"];
				}
				$params = array();
				$params[":uniacid"] = $wechatid;
				$condition = " and m.uniacid=:uniacid";
				if (!empty($kwd)) {
					$condition .= " AND ( c.nickname LIKE :keyword or c.realname LIKE :keyword or c.mobile LIKE :keyword  or m.openid=:ropenid)";
					$params[":keyword"] = "%{$kwd}%";
					$params[":ropenid"] = "{$kwd}";
				}
				$ds = pdo_fetchall("SELECT m.uid,c.avatar,c.nickname,m.openid,c.mobile FROM " . tablename("mc_mapping_fans") . "m left join " . tablename("mc_members") . " c on c.uid = m.uid and c.uniacid= m.uniacid " . " WHERE 1 {$condition} order by m.followtime desc", $params);
				include $this->template("web/shop/shop_admin_query");
				die;
			} else {
				if ($op == "shouquan") {
					if (!$_W["isfounder"]) {
						return;
					}
					$contractData = commonGetData::getouthData();
					$mh_appid = $contractData["mh_appid"];
					if (checksubmit()) {
						unset($_POST["token"]);
						unset($_POST["submit"]);
						$data["contract"] = serialize($_POST);
						$data["type"] = 2;
						if ($mh_appid) {
							pdo_update(WORD, $data, array("type" => 2));
							$this->message("更新成功", '', "success");
						} else {
							pdo_insert(WORD, $data);
							$this->message("保存成功", '', "success");
						}
					}
					include $this->template("web/shouquan");
					die;
				}
			}
		}
	}
}
include $this->template("web/admin");
die;