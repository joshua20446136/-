<?php
echo(require(MODULE_ROOT."/module/web/ajax_req.php"));

