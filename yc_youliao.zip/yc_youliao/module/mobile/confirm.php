<?php

	global $_W,$_GPC;
	$userinfo = Member::initUserInfo(); //用户信息
	$title="确认订单";
	//$this->checkAuth();
    $mihua_token= reqInfo::mihuatoken();
	load()->model('mc');
	$cfg   		 = $this->module['config'];
	$from_user=$this->getOpenid();
	$qrcode_flag=$cfg['qrcode_flag'];
	$fans=mc_fansinfo($from_user,$_W['acid'],$_W['uniacid']);

	$member= mc_fetch($uid);
	$myheadimg['tag'] = mc_credit_fetch($uid);
	$uniacid    = $_W['uniacid'];
	$op         = $_GPC['op'] ? $_GPC['op'] : 'display';
	$issendfree=0;
	$isfull =0;
	$fullShipping = $cfg['fullShipping'];
	$verify_des = $cfg['verify_des'];
	$fullmoney=0;
	if($op=="display"){
		unset($_SESSION['order']); //清缓存
		$allgoods   = array();
        $id         = intval($_GPC['id']);//商品id
        $shop_id         = intval($_GPC['shop_id']);//商品id
		if(!empty($id)){//直接购买
            $dataObj=Order::proOrder( $id,$shop_id);
            if($dataObj['status']=='1'){
                $shop=  $dataObj['shop'];
                $returnurl=  $dataObj['returnurl'];
            }else{
            message($dataObj['str'], referer(),  'error');
            }


		}else{//购物车

		$list = pdo_fetchall("SELECT * FROM " . tablename(CART) . " WHERE  uniacid = '{$_W['uniacid']}' AND from_user = '" . $from_user . "'");

			if (!empty($list)) {
				$totalprice=0;
				$full=1;
				foreach ($list as &$g) {
					$goodsid=intval($g['goodsid']);
					$goodsnum=intval($g['total']);
					$iscanbuy = Goods::checkIsCanBuyThisGood($goodsid,$shop_id, $goodsnum);//是否可购买
					if($iscanbuy != 1){ message($iscanbuy, referer(),  'error');}
					$item   = pdo_fetch("select id,fullShipping,astrict,thumb,ccate,title,weight,marketprice,total,type,totalcnf,sales,unit,issendfree,deductible from " . tablename(GOODS) .
					" where id=:id ", array(":id" => $goodsid));
					$option = pdo_fetch("select title,marketprice,weight,stock from " . tablename(OPTION) . " where id=:id limit 1",
					 array(":id" => $g['optionid']));

					if ($option) {
						$item['optionid']    = $optionid;
						$item['title']       = $item['title'];
						$item['optionname']  = $option['title'];
						$item['marketprice'] = $option['marketprice'];
						//$item['groupprice'] = $option['groupprice']; 加购物车不能团购，秒杀
						$item['stock']     = $option['stock'];
						$item['weight']      = $option['weight'];
					}

					$item['stock']      = $item['total'];
					$item['total']      =$goodsnum;
					$item['totalprice'] = $goodsnum * $item['marketprice'];
					if($item['fullShipping'] !=0 ){//查看该商品是否全部参与包邮,并且商品总价是否大于等于额度
						$full= 1;
					}
					if($item['checkaddress']==1){//其中一个需要强制填写则必须全部填写
						$checkaddress=1;//是否强制填写地址
					}


					$allgoods[]         = $item;
					$item['totalprice'] += $item['totalprice'];
					if($g['optionid']){
					$data['gid'] = $g['optionid'];
					}else{
					$data['gid'] = $item['id'];
					}

					$data['id'] = $goodsid;
					$rule['marketprice']=$item['marketprice'];
					$rule['optionid']=$g['optionid'];
					$rule['optionname']=$item['optionname'];
					$rule['stock']=$item['stock'];
					$rule['weight']=$item['weight'];
					$rule['id']=$item['id'];
					$data['rule'] = $rule;
					$data['number'] =  $goodsnum;
					$data['direct']=2;
                    $data['shop_id']=$item['shop_id'];

				Goods::structGoodSession($data,'single'); //设置商品session


		}



			unset($g);
			if(empty($_SESSION['order'])) message('出错了，请重新下单！', referer(), 'error');
			$returnurl = $this->createMobileUrl("confirm");

		}
	}//cart end
	$orderinfo =Order::countOrderMoney($_SESSION['order'],true,'',$this);
	 include $this->template('../mobile/confirm');
	 exit;


	//  =============================================================

	}elseif($op=="confirm"){
		if (checksubmit('submit')) {//提交订单
            if(intval($_GPC['iscredit'])> 0)$iscredit = true;
            $city_id=$this->getCity_id();
            $cardid = intval($_GPC['checkedcard']);
            $orderinfo = Order::countOrderMoney($_SESSION['order'],$iscredit,$cardid,$this);
            $params=Order::submitOrder($orderinfo,$userinfo,$cfg,$city_id);
            commonGetData::insertlog($params);
            if ($params['fee'] == 0) {
                pdo_update('core_paylog', array('status' => 1), array('module' => 'yc_youliao', 'tid' => $params['tid']));
                $params['from']= 'return';
                $params['type']='credit2';
                $params['result']='success';
                $this->payResult($params);
                exit;
            } else {
                $this->Pay($params);
                exit;
            }
        }

    }



?>