<?php
global $_GPC,$_W;
$cfg=$this->module['config'];
$op     = !empty($_GPC['op']) ? $_GPC['op'] : 'display';
$user= Member::initUserinfo(); //用户信息
$credits = commonGetData::getUserCreditList($user['openid']);
if($op=='post'){
    $uid         = mc_openid2uid($user['openid']);
    $in['uniacid']=$_W['uniacid'];
    $in['uid']=$uid;
    $in['openid']=$user['openid'];
    $in['money']=floatval($_GPC['money']);
    $in['addtime']=TIMESTAMP;
    pdo_insert(BALANCE,$in);
    $id=pdo_insertid();
    $mihua_token= reqInfo::mihuatoken();
    $tid=reqInfo::gettokenOrsn( 'ye'.$id,$mihua_token);
    $params = array(
        'tid' =>$tid,      //充值模块中的订单号，此号码用于业务模块中区分订单，交易的识别码
        'title' => '充值余额',          //收银台中显示的标题
        'fee' => $in['money'],      //收银台中显示需要支付的金额,只能大于 0
        'user' =>$user['openid'],     //付款用户, 付款的用户名(选填项)
    );
        $result=commonGetData::insertlog($params);
        if($result==1){
            $params['pytype']='ye';
            $this->pay($params);
            exit();
        }


}elseif($op=='record'){
    $status     = intval($_GPC['status']);
    $list=util::getAllDataBySingleTable(BALANCE,array('openid'=>$user['openid'],'status'=>$status),'balance_id desc ');
}
include $this->template('../mobile/balance');
exit;