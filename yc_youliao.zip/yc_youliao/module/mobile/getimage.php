<?php
global $_GPC,$_W;
$messageid = intval($_GPC['message_id']);
$moudleid = intval($_GPC['moudleid']);
$imageeenname = pdo_fetch('SELECT enname FROM ' . tablename(FIELDS) . " WHERE weid = {$_W['uniacid']} AND mid = {$moudleid} AND mtype in ('images','goodsthumbs','goodsbaoliao')");
if (empty($imageeenname)) {
echo '';
die;
} else {
$message = pdo_fetch('SELECT json2ser,content FROM ' . tablename(INFO) . " WHERE weid = {$_W['uniacid']} AND id = {$messageid} ");
$feildlist = $message['json2ser']==1 ? json_decode($message['content'],true) : unserialize($message['content']);
$imagesarr = $feildlist[$imageeenname['enname']];
    if ($imagesarr) {
        $html = '<div class="my-gallery">';
        foreach ($imagesarr as $k => $v) {
            $img = tomedia($v);
            $size = getimagesize($img);
            $tarwidth = $size[1];
            $tarheight = $size[0];

            $html .= ' <figure>
            <a href="' . $img . '" class="gallery-a" data-size="' . $tarwidth . 'x' . $tarheight . '" ><img class="pic" src="' . $img . '"/></a>
        </figure>';
        }
        $html .= '</div>
   
';
        echo $html;
    }
die;
}