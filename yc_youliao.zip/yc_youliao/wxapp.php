<?php 
defined("IN_IA") or die("Access Denied");
require IA_ROOT . "/addons/yc_youliao/class/defineData.php";
require IA_ROOT . "/addons/yc_youliao/class/commonGetData.php";
require IA_ROOT . "/addons/yc_youliao/class/util.php";
require IA_ROOT . "/addons/yc_youliao/class/reqInfo.php";
require IA_ROOT . "/addons/yc_youliao/class/function_common.class.php";
require IA_ROOT . "/addons/yc_youliao/model/Member.php";
require IA_ROOT . "/addons/yc_youliao/model/Shop_pro.php";
require IA_ROOT . "/addons/yc_youliao/model/Goods.php";
require IA_ROOT . "/addons/yc_youliao/model/Info.php";
require IA_ROOT . "/addons/yc_youliao/model/PayResult.php";
require IA_ROOT . "/addons/yc_youliao/model/Discount.php";
require IA_ROOT . "/addons/yc_youliao/model/Redpackage.php";
require IA_ROOT . "/addons/yc_youliao/model/Order.php";
require IA_ROOT . "/addons/yc_youliao/model/Group.php";
include_once IA_ROOT . "/framework/library/qrcode/phpqrcode.php";
load()->func("logging");
class Yc_youliaoModuleWxapp extends WeModuleWxapp
{
	public function __construct()
	{
		$this->cfg();
	}
	private function cfg()
	{
		global $_W;
		$_W["uniacid"] = $this->getUniacid();
		$cfg = pdo_fetchcolumn("SELECT settings FROM " . tablename("uni_account_modules") . " WHERE module = :module AND uniacid = :uniacid", array(":module" => MODULE, ":uniacid" => $_W["uniacid"]));
		$this->module = unserialize($cfg);
	}
	public function doPageTest()
	{
		global $_GPC, $_W;
		$errno = 0;
		$message = "sucess";
		$data = commonGetData::getAdv(1);
		return $this->result($errno, $message, $data);
	}
	private function getUerInfo()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$code = $_GPC["code"];
		$account_api = WeAccount::create();
		$oauth = $userinfo = $account_api->getOauthInfo($code);
		if (empty($userinfo)) {
			return $this->errorResult("2");
			die;
		}
		if (!empty($oauth) && !is_error($oauth)) {
			$_SESSION["openid"] = $oauth["openid"];
			$_SESSION["session_key"] = $oauth["session_key"];
			$fans = mc_fansinfo($oauth["openid"]);
			if (empty($fans)) {
				$record = array("openid" => $oauth["openid"], "uid" => 0, "acid" => $_W["acid"], "uniacid" => $_W["uniacid"], "salt" => random(8), "updatetime" => TIMESTAMP, "nickname" => $_GPC["nickName"], "follow" => "1", "followtime" => TIMESTAMP, "unfollowtime" => 0, "tag" => '');
				$email = md5($oauth["openid"]) . "@we7.cc";
				$email_exists_member = pdo_getcolumn("mc_members", array("email" => $email), "uid");
				if (!empty($email_exists_member)) {
					$uid = $email_exists_member;
				} else {
					$default_groupid = pdo_fetchcolumn("SELECT groupid FROM " . tablename("mc_groups") . " WHERE uniacid = :uniacid AND isdefault = 1", array(":uniacid" => $_W["uniacid"]));
					$data = array("uniacid" => $_W["uniacid"], "email" => $email, "salt" => random(8), "groupid" => $default_groupid, "createtime" => TIMESTAMP, "nickname" => $_GPC["nickName"], "avatar" => $_GPC["avatarUrl"], "gender" => $_GPC["gender"], "nationality" => '', "resideprovince" => '', "residecity" => '');
					pdo_insert("mc_members", $data);
					$uid = pdo_insertid();
				}
				$record["uid"] = $uid;
				$_SESSION["uid"] = $uid;
				$record["unionid"] = $oauth["unionid"];
				pdo_insert("mc_mapping_fans", $record);
			} else {
				if (empty($fans["unionid"]) && !empty($oauth["unionid"])) {
					$fansData["unionid"] = $oauth["unionid"];
					$fansData["nickname"] = $_GPC["nickName"];
					pdo_update("mc_mapping_fans", $fansData, array("openid" => $oauth["openid"]));
					$membersData["nickname"] = $_GPC["nickName"];
					$membersData["avatarUrl"] = $_GPC["avatarUrl"];
					pdo_update("mc_members", $membersData, array("uid" => $fans["uid"]));
				}
			}
		} else {
			$account_api->result(1, $oauth["message"]);
		}
		$member = Util::getSingelDataInSingleTable(MEMBER, array("openid_wxapp" => $userinfo["openid"]));
		logging_run($member);
		if (empty($member)) {
			$newData = array("uniacid" => $_W["uniacid"], "openid" => $userinfo["openid"], "openid_wxapp" => $userinfo["openid"], "nickname" => $_GPC["nickName"], "avatar" => $_GPC["avatarUrl"], "gender" => $_GPC["gender"], "wxapp" => 1, "logintime" => time());
			Member::mergeUser($newData, $oauth["unionid"], "openid");
		} else {
			Member::mergeOlduser($member, $oauth["unionid"], $_GPC["avatarUrl"], $_GPC["nickName"], "openid_wxapp", "openid");
		}
		if (empty($member["openid"])) {
			$member["openid"] = $userinfo["openid"];
		}
		return $member;
	}
	public function getUniacid()
	{
		global $_GPC, $_W;
		$uniacid = $_GPC["i"];
		$version = $_GPC["v"];
		$data = pdo_fetchcolumn(" SELECT modules FROM " . tablename("wxapp_versions") . " WHERE  uniacid = '{$uniacid}'  and version = '{$version}'   limit 1");
		$modules = unserialize($data);
		$_W["uniacid"] = $uniacid = $modules["yc_youliao"]["uniacid"];
		if (empty($_W["uniacid"])) {
			$uniacid = pdo_fetchcolumn("SELECT weid FROM " . tablename(CHANNEL) . " order by id asc limit 1");
		}
		return $uniacid;
	}
	public function successResult($data)
	{
		$errno = 0;
		$message = "sucess";
		return $this->result($errno, $message, $data);
	}
	public function errorResult($message)
	{
		$errno = 1;
		return $this->result($errno, $message);
	}
	public function doPageAttachurl()
	{
		global $_W;
		return $_W["attachurl"];
	}
	public function dopageGoAppPage()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$openid = $this->getUserBySeid();
		$member = Member::getMemberByopenid_wxapp($openid);
		$url = $_W["siteroot"] . "app/index.php?i=" . $_W["uniacid"] . "&c=entry&m=yc_youliao&uid=" . $member["id"];
		$cfg = $this->module["config"];
		$wxapp_type = 1;
		if (intval($cfg["wxapp_type"] == 0)) {
			$wxapp_type = 0;
		}
		$title = $cfg["title"];
		if (empty($title)) {
			$title = $_W["uniaccount"]["name"];
		}
		return $this->successResult(array("url" => $url, "wxapp_type" => $wxapp_type, "title" => $title));
	}
	public function dopageGetSeid()
	{
		global $_W, $_GPC;
		$userinfo = $this->getUerInfo();
		$myfun = new myfun();
		$sessionId = time() . $myfun->randombylength(8);
		cache_write($sessionId, $userinfo["openid"]);
		$_W["openid"] = $userinfo["openid"];
		return $this->successResult($sessionId);
	}
	public function getUserBySeid()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		logging_run("=====================\$_W['openid']==============" . $_W["openid"]);
		if (empty($_W["openid"])) {
			$seid = $_GPC["seid"];
			$userinfo = cache_load($seid);
			logging_run("=====================\$seid==============" . $seid);
			logging_run("=====================\$userinfo==============" . $userinfo);
			$_W["openid"] = $userinfo;
			if (empty($userinfo)) {
				return $this->errorResult("2");
				die;
			}
		}
		return $_W["openid"];
	}
	public function getMemberByOpenid()
	{
		global $_W;
		$openid = $this->getUserBySeid();
		$member = Member::getMemberByopenid($openid);
		if (empty($member)) {
			$member = Member::getMemberByopenid_wxapp($openid);
		}
		return $member;
	}
	public function doPageIndex()
	{
		global $_GPC, $_W;
		$_W["uniacid"] = $this->getUniacid();
		$info_condition = '';
		$lat = '';
		$lng = '';
		$formatted_address = '';
		$weatherdata = '';
		$city = '';
		$cfg = $this->module["config"];
		if (!empty($_GPC["lat"]) && !empty($_GPC["lng"])) {
			$lat = $_GPC["lat"];
			$lng = $_GPC["lng"];
			$cfg = $this->module["config"];
			$mapreq = ReqInfo::mapReq($cfg);
			$chagexy = ReqInfo::chagexy($cfg);
			$addresData = util::getDistrictByLatLng($lat, $lng, $mapreq, $chagexy);
			$formatted_address = $addresData["formatted_address"];
			$city = $addresData["city"];
			if ($city) {
				$sql_city = rtrim($city, "市");
				if ($cfg["issamecity"] == 0) {
					$info_condition .= " and city like '" . $sql_city . "%' ";
				}
				$weatherurl = ReqInfo::weatherreq();
				$weatherdata = util::getWeather($weatherurl, $city);
				$weather2 = json_decode($weatherdata, 1);
				if ($weather2["status"] == "1002") {
					$weatherdata = util::getWeather($weatherurl, $addresData["district"]);
				}
			}
		}
		$advs = commonGetData::getAdv(1);
		$moduleData = commonGetData::getAllChannel();
		$module = $moduleData[0];
		$cmodule = $moduleData[1];
		$msgNum = ReqInfo::msgNum($cfg);
		$hotMsg = commonGetData::getNewMsg($info_condition, $msgNum, $lat, $lng);
		$title = !empty($cfg["title"]) ? $cfg["title"] : $_W["uniaccount"]["name"];
		$data = array("city" => $city, "formatted_address" => $formatted_address, "weatherdata" => $weatherdata, "advs" => $advs, "module" => $module, "cmodule" => $cmodule, "hotMsg" => $hotMsg, "title" => $title);
		$uid = $_GPC["uid"];
		if ($uid) {
			$result = MEMBER::isqiandao($uid);
			$data["isSignIn"] = $result;
			if ($data["isSignIn"] == 1) {
				$qiandao_random = $cfg["qiandao_random"];
				if ($qiandao_random == 1) {
					$data["credit"] = -1;
				} else {
					if (!empty($cfg["qiandao_jifen"])) {
						$data["credit"] = $cfg["qiandao_jifen"];
					}
				}
			}
		}
		return $this->successResult($data);
	}
	public function doPageNewMsg()
	{
		global $_GPC, $_W;
		$_W["uniacid"] = $this->getUniacid();
		$info_condition = '';
		$lat = '';
		$lng = '';
		$cfg = $this->module["config"];
		if (!empty($_GPC["lat"]) && !empty($_GPC["lng"])) {
			$lat = $_GPC["lat"];
			$lng = $_GPC["lng"];
			$cfg = $this->module["config"];
			$mapreq = ReqInfo::mapReq($cfg);
			$chagexy = ReqInfo::chagexy($cfg);
			$addresData = util::getDistrictByLatLng($lat, $lng, $mapreq, $chagexy);
			$city = $addresData["city"];
			if ($city) {
				$sql_city = rtrim($city, "市");
				if ($cfg["issamecity"] == 0) {
					$info_condition .= " and city like '" . $sql_city . "%' ";
				}
			}
		}
		$msgNum = ReqInfo::msgNum($cfg);
		$data = commonGetData::getNewMsg($info_condition, $msgNum, $lat, $lng);
		return $this->successResult($data);
	}
	public function dopageCredit2money()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$cfg = $this->module["config"];
		$credit2money = $cfg["credit2money"];
		if (empty($credit2money)) {
			$credit2money = 0.1;
		}
		return $this->successResult($credit2money);
	}
	public function dopageGetLaction()
	{
		global $_GPC, $_W;
		if (!empty($_GPC["lat"]) && !empty($_GPC["lng"])) {
			$lat = $_GPC["lat"];
			$lng = $_GPC["lng"];
			$cfg = $this->module["config"];
			$mapreq = ReqInfo::mapReq($cfg);
			$chagexy = ReqInfo::chagexy($cfg);
			$addresData = util::getDistrictByLatLng($lat, $lng, $mapreq, $chagexy);
			return $this->successResult($addresData);
		}
	}
	public function doPageGetModuleById()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$id = intval($_GPC["id"]);
		if ($id == 0) {
			$errno = 1;
			$message = "id is null";
			return $this->result($errno, $message);
		}
		$search = $_GPC["search"];
		$where = '';
		if ($search) {
			$where = " and content like '%" . $search . "%' ";
		}
		$page = reqInfo::pageIndex();
		$num = reqInfo::num();
		$city = '';
		$cfg = $this->module["config"];
		if ($cfg["issamecity"] == 0) {
			$city = $_GPC["city"];
		}
		$data = commonGetData::getMsgById($id, $page, $num, $city, '', '', $where);
		return $this->successResult($data);
	}
	public function doPageGetModuleChildrenById()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$id = intval($_GPC["id"]);
		$data = Info::getChildrenMsg($id);
		return $this->successResult($data);
	}
	public function doPageGetInfoById()
	{
		global $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$id = intval($_GPC["id"]);
		$mid = intval($_GPC["mid"]);
		if ($id == 0) {
			$errno = 1;
			$message = "id is not null";
			return $this->result($errno, $message);
		}
		$data = commonGetData::getInfoById($id, $_W["uniacid"]);
		$data["content"] = $feildlist = unserialize($data["content"]);
		$imageeenname = pdo_fetch("SELECT enname FROM " . tablename(FIELDS) . " WHERE weid = {$_W["uniacid"]} AND mid = {$mid} AND mtype in ('images','goodsthumbs','goodsbaoliao')");
		$data["images"] = $feildlist[$imageeenname["enname"]];
		return $this->successResult($data);
	}
	public function doPageFields()
	{
		global $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$fieldslist = commonGetData::getfield_arr($_GPC["id"], $_W["uniacid"]);
		return $this->successResult($fieldslist);
	}
	public function doPageSubmit_imgs()
	{
		global $_W;
		$_W["uniacid"] = $this->getUniacid();
		$myfun = new MyFun();
		$imgdir = util::getAttImgdir();
		$uplogo_path = ATTACHMENT_ROOT . $imgdir;
		if (!is_dir($uplogo_path)) {
			$res = mkdir($uplogo_path, 511, true);
		}
		$img_file_name = time() . $myfun->randombylength(8) . "." . $myfun->fileext($_FILES["file"]["name"]);
		if (move_uploaded_file($_FILES["file"]["tmp_name"], $uplogo_path . $img_file_name)) {
			$restult = true;
		} else {
			$restult = false;
		}
		$webimgurl = tomedia($imgdir . $img_file_name);
		$data = array("img_dir" => $imgdir . $img_file_name, "img_path" => $webimgurl);
		return $this->successResult($data);
	}
	public function doPageAddInfo()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$openid = $this->getUserBySeid();
		$info = new Info();
		$userinfo = Member::getMemberByopenid($openid);
		$black = Member::getBlack($userinfo["id"]);
		if (!empty($black)) {
			$this->errorResult("很抱歉，您已被移入黑名单");
		}
		$res = $info->postInfo($openid, 2);
		return $this->successResult($res);
	}
	public function doPageGetInfoByUser()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$openid = $this->getUserBySeid();
		$page = reqInfo::pageIndex();
		$num = reqInfo::num();
		$info = new Info();
		$haspay = $_GPC["haspay"];
		$status = $_GPC["status"];
		$isneedpay = $_GPC["isneedpay"];
		$where = '';
		if ($haspay) {
			$where .= " AND haspay= " . $haspay;
		}
		if ($isneedpay) {
			$where .= " AND isneedpay= " . $isneedpay;
		}
		if ($status) {
			$where .= " AND status=1 ";
		} else {
			$where .= " AND status=0 ";
		}
		$res = $info->getInfoByuser($openid, $where, $page, $num);
		$res = $this->pro_info($res);
		return $this->successResult($res);
	}
	public function doPageGetPayInfoByUser()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$openid = $this->getUserBySeid();
		$page = reqInfo::page();
		$num = reqInfo::num();
		$info = new Info();
		$res = $info->getPayInfoByuser($openid, '', $page, $num);
		$res = $this->pro_info($res);
		return $this->successResult($res);
	}
	public function pro_info($res)
	{
		$_W["uniacid"] = $this->getUniacid();
		foreach ($res as $k => $v) {
			$module = pdo_fetch("SELECT name FROM " . tablename(CHANNEL) . " WHERE weid = {$_W["uniacid"]} AND id = {$v["mid"]}");
			$res[$k]["con"] = $v["json2ser"] == 1 ? json_decode($v["content"], true) : unserialize($v["content"]);
			$res[$k]["modulename"] = $module["name"];
		}
		return $res;
	}
	public function doPageAddviews()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$cfg = $this->module["config"];
		$views_num = intval($cfg["views_num"]);
		$id = intval($_GPC["message_id"]);
		$info = new Info();
		$message = $info->getInfoById($id);
		if ($views_num > 0) {
			$views = mt_rand(1, $views_num);
			$views = $message["views"] + $views;
		} else {
			$views = $message["views"] + 1;
		}
		pdo_update(INFO, array("views" => $views), array("id" => $id));
		return $this->successResult($views);
	}
	public function doPageDeleteInfo()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$id = intval($_GPC["message_id"]);
		$openid = $this->getUserBySeid();
		$info = new Info();
		$message = $info->getInfoByOId($openid, $id);
		if ($message) {
			pdo_delete(INFO, array("id" => $id, "openid" => $openid));
			return $this->successResult("delete success");
		} else {
			return $this->successResult("data is null");
		}
	}
	public function doPageGetTopInfoByUser()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$openid = $this->getUserBySeid();
		$page = reqInfo::pageIndex();
		$num = reqInfo::num();
		$info = new Info();
		$res = $info->getTopInfoByuser($openid, '', $page, $num);
		$res = $this->pro_info($res);
		return $this->successResult($res);
	}
	public function doPageGetCollect()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$openid = $this->getUserBySeid();
		$page = reqInfo::pageIndex();
		$num = reqInfo::num();
		$info = new Info();
		$info_id = intval($_GPC["message_id"]);
		if ($info_id > 0) {
			$where = " and b.id=" . $info_id;
		}
		$res = $info->getCollect($openid, $page, $num, $where);
		return $this->successResult($res);
	}
	public function doPageProCollect()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$openid = $this->getUserBySeid();
		$info = new Info();
		$res = $info->proCollect($openid);
		return $this->result($res["error"], $res["message"]);
	}
	public function doPageComment()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$type = intval($_GPC["type"]);
		$id = intval($_GPC["id"]);
		$openid = $this->getUserBySeid();
		if ($type == 1) {
			if ($id == 0) {
				return $this->errorResult("id is null");
			}
			$info = trim($_GPC["info"]);
			$pid = intval($_GPC["pid"]);
			if (empty($info)) {
				return $this->errorResult("评论内容不能为空");
				die;
			}
			$data = array("uniacid" => $_W["uniacid"], "addtime" => TIMESTAMP, "openid" => $openid, "info" => $info, "info_id" => $id, "parent_id" => $pid);
			$result = pdo_insert(INFO_COMMENT, $data);
			if (!empty($result)) {
				return $this->successResult($data);
			}
		} else {
			if ($id > 0) {
				$comment_where["info_id"] = $id;
			} else {
				$comment_where["openid"] = $openid;
			}
			$orderby = " comment_id ASC ";
			$comment = util::getAllDataBySingleTable(INFO_COMMENT, $comment_where, $orderby, $select = "*", $type = "1");
			foreach ($comment as $k => $v) {
				$memberData = Member::getSingleUser($v["openid"]);
				$comment[$k]["avatar"] = $memberData["avatar"];
				$comment[$k]["nickname"] = $memberData["nickname"];
				$comment[$k]["addtime"] = date("Y-m-d H:i", $v["addtime"]);
			}
			return $this->successResult($comment);
		}
	}
	public function doPageQiandao()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$uid = intval($_GPC["uid"]);
		if ($uid == 0) {
			return $this->errorResult("uid is null");
		}
		$cfg = $this->module["config"];
		$res = Member::qiandao($uid, $cfg);
		return $this->successResult($res);
	}
	public function doPageGetTitle()
	{
		global $_W;
		$_W["uniacid"] = $this->getUniacid();
		$cfg = $this->module["config"];
		$title = $cfg["index_title"];
		if (empty($title)) {
			$title = $_W["uniaccount"]["name"];
		}
		return $this->successResult($title);
	}
	public function doPageGetInfoOdersn()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$openid = $this->getUserBySeid();
		$id = intval($_GPC["message_id"]);
		$res = util::getSingelDataInSingleTable(INFOORDER, array("message_id" => $id, "from_user" => $openid), "*", 2);
		return $this->successResult($res);
	}
	public function doPageGetDiscountMoney()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$page = reqInfo::pageIndex();
		$num = reqInfo::num();
		$shop_id = floatval($_GPC["shop_id"]);
		$where["shop_id"] = $shop_id;
		$discount = Util::getAllDataInSingleTable(DISCOUNT, $where, $page, $num);
		$paynum = floatval($_GPC["paynum"]);
		$list = Discount::getmoney($discount, $paynum);
		return $this->successResult($list);
	}
	public function doPageGetCate()
	{
		global $_W;
		$_W["uniacid"] = $this->getUniacid();
		$data = Shop::getCcate();
		return $this->successResult($data);
	}
	public function doPageGetPCate()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$cid = intval($_GPC["cid"]);
		if ($cid > 0) {
			$data = Shop::getCcateBypid($cid);
		} else {
			$data = Shop::getCate();
		}
		return $this->successResult($data);
	}
	public function doPageGetCateByCid()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$pid = intval($_GPC["cate_id"]);
		$data = Shop::getCcateBypid($pid);
		return $this->successResult($data);
	}
	public function doPageGetShopPosition()
	{
		global $_W;
		$_W["uniacid"] = $this->getUniacid();
		$city = pdo_fetchall(" SELECT * FROM " . tablename(CITY) . " WHERE  uniacid = '{$_W["uniacid"]}' ORDER BY  orderby asc");
		$area = pdo_fetchall(" SELECT * FROM " . tablename(AREA) . " WHERE  uniacid = '{$_W["uniacid"]}'  and (parent_id =0 or parent_id is null) ORDER BY  orderby asc");
		$business = pdo_fetchall(" SELECT * FROM " . tablename(AREA) . " WHERE  uniacid = '{$_W["uniacid"]}'  and parent_id >0 ORDER BY  orderby asc");
		return $this->successResult(array("city" => $city, "area" => $area, "business" => $business));
	}
	public function doPageGetShopArea()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$city_id = intval($_GPC["city_id"]);
		if ($city_id == 0) {
			return $this->errorResult("城市ID不能为空");
		}
		$list = Shop::getAreaByCityid($city_id);
		return $this->successResult($list);
	}
	public function doPageGetShopBusiness()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$area_id = intval($_GPC["area_id"]);
		if ($area_id == 0) {
			return $this->errorResult("区域ID不能为空");
		}
		$list = Shop::getBusinessByAreaid($area_id);
		return $this->successResult($list);
	}
	public function doPageGetShop()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$shop_id = intval($_GPC["shop_id"]);
		$data = Shop::getShopInfo($shop_id);
		$shopObj = new Shop();
		$data = $shopObj->proShopImg($data);
		return $this->successResult($data);
	}
	public function doPageGetGood()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$userinfo = $this->getMemberByOpenid();
		$shop_id = intval($_GPC["shop_id"]);
		$goods_id = intval($_GPC["good_id"]);
		$data = Goods::getSingleGood($goods_id, $shop_id);
		$data["thumb"] = tomedia($data["thumb"]);
		if ($data["is_time"] == "1") {
			$ms_status = Goods::ms_status($data);
			$data["times_flag"] = $ms_status;
			$date1 = date("Y-m-d", time());
			$changedate = strtotime($date1 . " " . $data["timeend"] . ":00:00");
			$arr = util::time_tran($changedate);
			$data["timelaststr"] = $arr[0];
			$data["timelast"] = $arr[1];
		}
		$maxcredit = $data["credit"];
		if ($maxcredit > 0) {
			$usercredit = Member::getMcDataByopenid($userinfo["openid"]);
			if ($usercredit["credit1"] >= $maxcredit) {
				$data["minuscredit"] = intval($maxcredit);
			} else {
				$data["minuscredit"] = intval($usercredit["credit1"]);
			}
			$cfg = $this->module["config"];
			$credit2money = $cfg["credit2money"];
			$credit2money = !empty($credit2money) ? $credit2money : 0.1;
			$data["creditNum"] = $data["minuscredit"] * $credit2money;
		}
		if ($data["firstcut"] > 0) {
			$order = Order::getSingleOrderByStatus(array("openid" => $userinfo["openid"]), " >=1 ");
			if (!$order) {
				$data["first"] = true;
			}
		}
		return $this->successResult($data);
	}
	public function doPageGetGood_list()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$page = reqInfo::pageIndex();
		$num = reqInfo::num();
		$where["shop_id"] = intval($_GPC["shop_id"]);
		$data = Goods::getAllGood($where, $page, $num);
		return $this->successResult($data[0]);
	}
	public function doPageGetShopList()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$page = reqInfo::pageIndex();
		$num = reqInfo::num();
		$cate_id = intval($_GPC["cid"]);
		$condition = '';
		if ($cate_id > 0) {
			$condition .= " and (s.ccate_id =" . $cate_id . " or s.pcate_id =" . $cate_id . " ) ";
		}
		$lat = $_GPC["lat"];
		$lng = $_GPC["lng"];
		$shopObj = new Shop();
		$isgroup = $shopObj->getShopList($page, $num, $lat, $lng, $condition);
		return $this->successResult($isgroup);
	}
	public function doPageGetAdv()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$type = intval($_GPC["type"]);
		$advs = commonGetData::getAdv($type);
		return $this->successResult($advs);
	}
	public function doPageShop_renew()
	{
		global $_W;
		$_W["uniacid"] = $this->getUniacid();
		$cfg = $this->module["config"];
		$one = $cfg["one_year_money"];
		if (is_numeric($one) === false) {
			$one = 0;
		}
		$two = $cfg["one_two_money"];
		if (is_numeric($two) === false) {
			$two = 0;
		}
		$three = $cfg["one_three_money"];
		if (is_numeric($three) === false) {
			$three = 0;
		}
		return $this->successResult(array("one" => $one, "two" => $two, "three" => $three));
	}
	public function doPageCheckShopAdmin()
	{
		global $_W;
		$_W["uniacid"] = $this->getUniacid();
		$member = $this->getMemberByOpenid();
		$_W["openid"] = $openid = $member["openid"];
		$data = Shop::isshop_admin($openid);
		load()->model("mc");
		$uid = Member::getUidByopenid($member["openid"]);
		$myfansx = Member::getMcDataByuid($uid);
		$uid_wxapp = Member::getUidByopenid($member["openid_wxapp"]);
		$myfansx_wxapp = Member::getMcDataByuid($uid_wxapp);
		$member["credit"] = $myfansx["credit1"] + $myfansx_wxapp["credit1"];
		$cfg = $this->module["config"];
		if ($cfg["shop_enter"] == 1) {
			return $this->successResult(array("status" => 3, "member" => $member));
		}
		if ($data) {
			$status = 1;
			$shop_id = intval($data["shop_id"]);
		} else {
			$status = 0;
			$shop_id = 0;
		}
		$url = $_W["siteroot"] . "app/index.php";
		return $this->successResult(array("status" => $status, "url" => $url, "shop_id" => $shop_id, "acid" => $_W["uniacid"], "member" => $member));
	}
	public function doPageShop_in()
	{
		global $_GPC, $_W;
		$_W["uniacid"] = $this->getUniacid();
		$cfg = $this->module["config"];
		$userinfo = $this->getMemberByOpenid();
		$openid = $userinfo["openid"];
		$shop_id = intval($_GPC["shop_id"]);
		$member = Member::getMemberByopenid($openid);
		$mid = $member["id"];
		$type = intval($_GPC["shop_renew"]);
		$renewData = Shop::getShopRenewPrice($type, $cfg["one_year_money"], $cfg["two_year_money"], $cfg["three_year_money"]);
		$price = $renewData[0];
		$status = $renewData[1];
		$res = Shop::editShopInfo($mid, $shop_id, 0);
		$res1 = intval($res);
		$ordersn = Shop::insertRenew($type, $status, $price, $cfg, 0, $res1, $mid);
		if ($res1 > 0 && $status == 1) {
			$res = Shop::shopFreeRenew($shop_id, $member["nickname"], $cfg["shop_enter_price"]);
			if ($res == 1) {
				return $this->successResult(array("status" => 0));
			}
		} else {
			if ($res1 > 0 && $status == 0) {
				$mihua_token = reqInfo::mihuatoken();
				$tid = reqInfo::gettokenOrsn("renew" . $ordersn, $mihua_token);
				$params = array("tid" => $tid, "title" => $_GPC["shop_name"] . "--商户入驻缴费", "fee" => $price, "user" => $openid);
				$result = commonGetData::insertlog($params);
				if ($result == 1) {
					return $this->successResult(array("status" => 0, "ordersn" => $tid));
				}
			} else {
				if ($res1 == 0) {
					return $this->successResult(array("status" => 3, "reason" => $res));
				}
			}
		}
	}
	public function doPageGetDiscount()
	{
		global $_GPC, $_W;
		$_W["uniacid"] = $this->getUniacid();
		$page = reqInfo::pageIndex();
		$num = reqInfo::num();
		$shop_id = intval($_GPC["shop_id"]);
		$where["shop_id"] = $shop_id;
		$discount = Util::getAllDataInSingleTable(DISCOUNT, $where, $page, $num);
		return $this->successResult($discount[0]);
	}
	public function doPageGetDisOrsn()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$ordersn = util::getordersn(DISCOUNT_RE);
		$userinfo = $this->getMemberByOpenid();
		$shop_id = floatval($_GPC["shop_id"]);
		$d_id = intval($_GPC["d_id"]);
		$paynum = floatval($_GPC["paynum"]);
		$paymoney = floatval($_GPC["paymoney"]);
		$in = array();
		$in["uniacid"] = $_W["uniacid"];
		$in["ordersn"] = $ordersn;
		$in["mid"] = $userinfo["id"];
		$in["aftermoney"] = $paynum;
		$in["paymoney"] = $paymoney;
		$in["createtime"] = TIMESTAMP;
		$in["shop_id"] = $shop_id;
		$in["discount_id"] = $d_id;
		pdo_insert(DISCOUNT_RE, $in);
		$id = pdo_insertid();
		$mihua_token = reqInfo::mihuatoken();
		$tid = reqInfo::gettokenOrsn("dis" . $id, $mihua_token);
		return $this->successResult(array("status" => 0, "ordersn" => $tid));
	}
	public function doPageMyDiscount()
	{
		global $_GPC, $_W;
		$_W["uniacid"] = $this->getUniacid();
		$userinfo = $this->getMemberByOpenid();
		$page = reqInfo::page();
		$num = reqInfo::num();
		$id = $_GPC["id"];
		if ($id > 0) {
			$sqlwhere = " and r.id=" . $id;
		}
		$data = commonGetData::getDiscount($page, $num, $userinfo["id"], $sqlwhere);
		$list = $data[0];
		$info = array();
		foreach ($list as $k => $v) {
			$v["createtime"] = date("Y-m-d H:i", $v["createtime"]);
			$v["logo"] = tomedia($v["logo"]);
			$info[] = $v;
		}
		return $this->successResult(array("status" => 0, "list" => $list));
	}
	public function doPageGetOrderOrsn()
	{
		global $_GPC, $_W;
		$_W["uniacid"] = $this->getUniacid();
		$cfg = $this->module["config"];
		$userinfo = $this->getMemberByOpenid();
		$id = intval($_GPC["id"]);
		$shop_id = intval($_GPC["shop_id"]);
		$orderOjb = new Order();
		$dataObj = $orderOjb->proOrder($id, $shop_id);
		if ($dataObj["status"] == "1") {
			$orderinfo = $dataObj["orderinfo"];
			$params = Order::submitOrder($orderinfo, $userinfo, $cfg, '');
			return $this->successResult($params);
		} else {
			return $this->errorResult($dataObj["str"]);
		}
	}
	public function doPageGetRedOrsn()
	{
		global $_GPC, $_W;
		$_W["uniacid"] = $this->getUniacid();
		$red = new Redpackage();
		$userinfo = $this->getMemberByOpenid();
		$cfg = $this->module["config"];
		$mapreq = ReqInfo::mapReq($cfg);
		$chagexy = ReqInfo::chagexy($cfg);
		$lat = $_GPC["lat"];
		$lng = $_GPC["lng"];
		$addresData = util::getDistrictByLatLng($lat, $lng, $mapreq, $chagexy);
		$city = $addresData["city"];
		if ($_GPC["xsthumb"]) {
			$xsthumb = json_encode($_GPC["xsthumb"]);
			$xsthumb = "[" . $xsthumb . "]";
		}
		$params = $red->addRed($userinfo, $city, $cfg["red_num"], $lng, $lat, $xsthumb);
		if ($params["error"] == 1) {
			$this->errorResult($params["str"]);
		} else {
			return $this->successResult($params);
		}
	}
	public function doPagePay()
	{
		global $_GPC, $_W;
		$_W["uniacid"] = $this->getUniacid();
		$openid = $this->getUserBySeid();
		$member = Member::getMemberByopenid($openid);
		$_W["openid"] = $member["openid_wxapp"];
		$order = array("tid" => $_GPC["ordersn"], "user" => $_W["openid"], "fee" => floatval($_GPC["sum"]), "title" => $_W["account"]["name"] . "支付");
		pdo_delete("core_paylog", array("tid" => $_GPC["ordersn"]));
		$pay_params = $this->pay($order);
		if (is_error($pay_params)) {
			return $this->result(1, $pay_params, $member["wxapp_openid"]);
		}
		return $this->result(0, '', $pay_params);
	}
	public function payResult($params)
	{
		global $_W;
		$token = reqInfo::gettoken();
		if ($token == '') {
			return;
		}
		$pay_orsn = reqInfo::gettokenNum($params["tid"], $token);
		logging_run(" =======tokenid==========  : " . $pay_orsn);
		logging_run(" =======tid==========  : " . $params["tid"]);
		if ($pay_orsn == '') {
			return;
		}
		$id = $pay_orsn;
		$PayResult = new PayResult();
		$logtag = $PayResult->checkReq($params, $id, "1");
		if ($logtag == 0) {
			return;
		}
		$params["tid"] = $id;
		$ordersnlen = strlen($params["tid"]);
		$paydetail = $logtag["tag"];
		$logtag = unserialize($logtag["tag"]);
		logging_run($params);
		if ($params["result"] == "success" && $params["from"] == "notify") {
			if (strstr($id, "dis")) {
				$PayResult->payresult_dis($params);
			} else {
				if (strstr($id, "ye")) {
					$PayResult->payresult_ye($params);
				} else {
					if (strstr($id, "orsn")) {
						$PayResult->payresult_order($params);
					} else {
						if (strstr($id, "renew")) {
							$PayResult->payresult_renew($params);
						} else {
							if (strstr($id, "redpackage")) {
								$cfg = $this->module["config"];
								$PayResult->payresult_redpackage($params, $cfg["redMsg"], $cfg["redMsg_num"], $cfg["redMsgUser"]);
							} else {
								if (strstr($id, "shang")) {
									$PayResult->payresult_shang($params);
								} else {
									if ($ordersnlen == 15) {
										$PayResult->payresult_info($params, $paydetail, $logtag);
									} else {
										if ($ordersnlen == 20) {
											$PayResult->payresult_zd($params, $paydetail, $logtag);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	public function doPageGetRed()
	{
		global $_W, $_GPC;
		$page = reqInfo::pageIndex();
		$num = reqInfo::num();
		$lat = $_GPC["lat"];
		$lng = $_GPC["lng"];
		$type = intval($_GPC["type"]);
		$list = Redpackage::getRedList($page, $num, $lat, $lng, $type);
		return $this->successResult(array("status" => 0, "list" => $list));
	}
	public function doPageGetRedDetail()
	{
		global $_W, $_GPC;
		$id = intval($_GPC["id"]);
		if ($id > 0) {
			$page = reqInfo::pageIndex();
			$num = reqInfo::num();
			$userinfo = $this->getMemberByOpenid();
			$userData = Redpackage::checkRed($id, $userinfo);
			$redpackageData = Redpackage::getRedpackage($page, $num, "r.red_id=" . $id);
			$redpackageData = $redpackageData[0];
			if ($redpackageData["xsthumb"]) {
				$redpackageData["xsthumb"] = json_decode($redpackageData["xsthumb"]);
				foreach ((array) $redpackageData["xsthumb"] as $a => $b) {
					if ($b) {
						$v["xsthumb"][$a] = tomedia($b);
					}
					$redpackageData["xsthumb"] = $v;
				}
			}
			$getredpackageData = Redpackage::getRedpackageRecords("red_id=" . $id);
			foreach ($getredpackageData as $a => $b) {
				$getredpackageData[$a]["create_time"] = date("Y-m-d H:i", $b["create_time"]);
			}
			return $this->successResult(array("status" => 0, "userData" => $userData, "redpackageData" => $redpackageData, "getredpackageData" => $getredpackageData));
		} else {
			return $this->errorResult("红包id不能为空");
		}
	}
	public function doPageSnatchRed()
	{
		global $_W, $_GPC;
		$id = intval($_GPC["id"]);
		if ($id > 0) {
			$page = reqInfo::pageIndex();
			$num = reqInfo::num();
			$userinfo = $this->getMemberByOpenid();
			$result = Redpackage::snatchRed($page, $num, $id, $userinfo);
			if ($result["code"] == "1000") {
				$result["nickname"] = $userinfo["nickname"];
				$result["avatar"] = $userinfo["avatar"];
				$result["createtime"] = date("Y-m-d H:i", TIMESTAMP);
			}
			return $this->successResult($result);
		} else {
			return $this->errorResult("红包id不能为空");
		}
	}
	public function doPageGetOrderlist()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$page = reqInfo::pageIndex();
		$num = reqInfo::num();
		$openid = $this->getUserBySeid();
		$where["openid"] = $openid;
		$status = $_GPC["status"];
		if ($status == "all") {
			$where["status>"] = 0;
		} else {
			if (intval($status >= 0)) {
				$where["status"] = intval($status);
			}
		}
		$data = Order::getorderlist($where, $page, $num);
		$list = $data[0];
		$goods = $data[1];
		return $this->successResult(array("status" => 0, "list" => $list, "goods" => $goods, "status" => $status));
	}
	public function doPageGetOrderDetail()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$id = intval($_GPC["id"]);
		$where["id"] = $id;
		$item = util::getSingelDataInSingleTable(ORDER, $where);
		$item["createtime"] = date("Y-m-d H:i", $item["createtime"]);
		$goods = Order::getGoodById($id);
		return $this->successResult(array("status" => 0, "list" => $item, "goods" => $goods));
	}
	public function doPageGetGrouplist()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$page = reqInfo::page();
		$num = reqInfo::num();
		$openid = $this->getUserBySeid();
		$wherea["openid"] = $openid;
		$gstatus = intval($_GPC["gstatus"]);
		$wherea["groupid>"] = 1;
		$statusstr = '';
		if ($gstatus == 1) {
			$whereb["overtime>"] = time();
			$whereb["lastnumber>"] = 0.1;
			$whereb["status"] = 1;
		}
		if ($gstatus == 2) {
			$statusstr .= " AND b.`status` = 2 ";
		}
		if ($gstatus == 3) {
			$whereb["lastnumber"] = 0;
			$statusstr .= " OR b.`status` = 3 ";
		}
		if ($gstatus == 4) {
			$wherea["status"] = 0;
			$statusstr .= " and a.ordertype in(2,3) ";
		}
		$select = "a.ordersn, a.id AS idoforder,a.groupid,a.status AS astatus,a.groupid,b.*,b.id AS bid,b.status AS bstatus,c.order_status as cstatus,d.goods_id ,d.shop_id,d.thumb,d.marketprice ";
		$data = Group::getAllGroupOrder($wherea, $whereb, $statusstr, $select, $page, $num, " a.`id` DESC ", false);
		$list = $data[0];
		foreach ((array) $list as $k => $v) {
			$list[$k]["thumb"] = tomedia($v["thumb"]);
			$list[$k]["gstatus"] = Group::decodeGroupStatus($v["bstatus"], $v["overtime"], $v["isrefund"], $v["lastnumber"]);
		}
		return $this->successResult(array("status" => 0, "list" => $list, "gstatus" => $gstatus));
	}
	public function doPageGetGroupDetail()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$openid = $this->getUserBySeid();
		$id = intval($_GPC["id"]);
		$groupinfo = Group::getSingleGroup($id);
		if (empty($groupinfo)) {
			return $this->errorResult("团购不存在");
		}
		$groupinfo["thumb"] = tomedia($groupinfo["thumb"]);
		$groupprice = util::getSingelDataInSingleTable(ORDER, array("groupid" => $id, "openid" => $openid), "price");
		$groupprice = $groupprice["price"];
		$groupinfo["gstatus"] = Group::decodeGroupStatus($groupinfo["status"], $groupinfo["overtime"], $groupinfo["isrefund"], $groupinfo["lastnumber"]);
		$isingroup = Order::getSingleOrderByStatus(array("groupid" => $id, "openid" => $_W["openid"]), " NOT IN (1,2) ");
		$isgroup = Group::getHotGroup();
		$member_list = Group::getGroupMemberWithCache($id);
		foreach ($member_list as $k => $v) {
			$member_list[$k]["paytime"] = date("Y-m-d H:i", $v["paytime"]);
		}
		return $this->successResult(array("status" => 0, "groupprice" => $groupprice, "groupinfo" => $groupinfo, "isingroup" => $isingroup, "member_list" => $member_list, "isgroup" => $isgroup));
	}
	public function doPageGetRedbag()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$openid = $this->getUserBySeid();
		$type = intval($_GPC["type"]);
		$page = reqInfo::pageIndex();
		$num = reqInfo::num();
		$Redpackage = new Redpackage();
		if ($type == 1) {
			$list = $Redpackage->sendRedpackageRecordList($openid, $page, $num);
		} else {
			$list = $Redpackage->getRedpackageRecordList($openid, $page, $num);
		}
		return $this->successResult(array("status" => 0, "list" => $list));
	}
	public function doPageGetCreditList()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$openid = $this->getUserBySeid();
		$page = reqInfo::page();
		$num = reqInfo::num();
		$where["openid"] = $openid;
		$where["module"] = "yc_youliao";
		$where["type>"] = "0";
		$arr = util::getAllDataInSingleTable("core_paylog", $where, $page, $num, "plid desc ");
		$credits = $arr[0];
		return $this->successResult(array("status" => 0, "list" => $credits));
	}
	public function doPageGetActionGoods()
	{
		global $_W, $_GPC;
		$_W["uniacid"] = $this->getUniacid();
		$page = reqInfo::pageIndex();
		$num = reqInfo::num();
		$type = intval($_GPC["type"]);
		$condition = '';
		$condition .= Shop::getShopEndtime();
		$joinCity = Shop::joinCity();
		$city_name = $_GPC["city"];
		$city_name = rtrim($city_name, "市");
		$cityCondition = commonGetData::getCityId($city_name);
		if ($type == 0) {
			$list = Goods::getXsmsGoods($joinCity, $condition . $cityCondition, $page, $num);
			$list = $list["xsms"];
		} else {
			if ($type == 1) {
				$condition .= " and s.is_group=1 and g.is_group=1 and  g.groupnum>0 ";
			} else {
				if ($type == 2) {
					$condition .= "  and g.isfirstcut >0 ";
				} else {
					if ($type == 3) {
						$condition .= "  and g.credit >0 ";
					}
				}
			}
			$list = Goods::getGroup($joinCity, $condition, $cityCondition, $page, $num);
		}
		foreach ($list as $k => $v) {
			$list[$k]["thumb"] = tomedia($v["thumb"]);
			$list[$k]["logo"] = tomedia($v["logo"]);
		}
		return $this->successResult(array("status" => 0, "list" => $list));
	}
}