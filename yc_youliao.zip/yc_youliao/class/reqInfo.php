<?php
class ReqInfo
{
	public static function mapReq($cfg)
	{
		$ak = $cfg["mapak"];
		if (empty($ak)) {
			return "https://api.map.baidu.com/geocoder/v2/?ak=sUgbA9k3BkDWbGZwHWP6EAhe6DaR4z6N&output=json&pois=1";
		} else {
			return "https://api.map.baidu.com/geocoder/v2/?output=json&pois=1&ak=" . $ak;
		}
	}
	public static function mapUrl($cfg)
	{
		$ak = $cfg["mapak"];
		if (empty($ak) || $ak == '') {
			return "https://api.map.baidu.com/api?v=2.0&ak=sUgbA9k3BkDWbGZwHWP6EAhe6DaR4z6N&s=1";
		} else {
			return "https://api.map.baidu.com/api?v=2.0&s=1&ak=" . $ak;
		}
	}
	public static function chagexy($cfg)
	{
		$ak = $cfg["mapak"];
		if (empty($ak) || $ak == '') {
			return "https://api.map.baidu.com/geoconv/v1/?ak=sUgbA9k3BkDWbGZwHWP6EAhe6DaR4z6N&from=1&to=5&s=1";
		} else {
			return "https://api.map.baidu.com/geoconv/v1/?from=1&s=1&to=5&ak=" . $ak;
		}
	}
	public static function weatherreq()
	{
		return "http://wthrcdn.etouch.cn/weather_mini?city=";
	}
	public static function msgNum($cfg)
	{
		$shownum = intval($cfg["showChannelNum"]);
		if (empty($shownum)) {
			$shownum = 5;
		}
		return $shownum;
	}
	public static function num()
	{
		global $_GPC;
		$num = intval(empty($_GPC["num"]) ? 20 : $_GPC["num"]);
		return $num;
	}
	public static function page()
	{
		global $_GPC;
		$page = intval(empty($_GPC["page"]) ? 0 : $_GPC["page"]);
		return $page;
	}
	public static function pageIndex()
	{
		global $_GPC;
		$page = intval(empty($_GPC["page"]) ? 1 : $_GPC["page"]);
		$num = self::num();
		$start = ($page - 1) * $num;
		return $start;
	}
	public static function mihuaUrl()
	{
		return "http://api.szmihua.com/";
	}
	public static function gettokenNum($ordersn, $token)
	{
		$url = self::mihuaUrl() . "module/order?order_secret=" . $ordersn;
		$ch = curl_init();
		util::setCurl($token, $url, $ch);
		$content = curl_exec($ch);
		curl_close($ch);
		if (empty($content) && $content == '') {
			return '';
		} else {
			$json_content = json_decode($content);
			if ($json_content->code == 0) {
				return $json_content->data;
			} else {
				return '';
			}
		}
	}
	public static function gettokenOrsn($ordersn, $token)
	{
		$post_data["order_sn"] = $ordersn;
		$url = self::mihuaUrl() . "module/order";
		$crl = curl_init();
		util::setCurl($token, $url, $crl);
		curl_setopt($crl, CURLOPT_POST, true);
		$post_data["order_sn"] = $ordersn;
		curl_setopt($crl, CURLOPT_POSTFIELDS, $post_data);
		$content = curl_exec($crl);
		curl_close($crl);
		if (empty($content) && $content == '') {
			return '';
		} else {
			$json_content = json_decode($content, 1);
			if ($json_content["code"] == 0) {
				return $json_content["data"];
			} else {
				return '';
			}
		}
	}
	public static function cfg()
	{
		global $_W;
		$cfg = pdo_fetchcolumn("SELECT settings FROM " . tablename("uni_account_modules") . " WHERE module = :module AND uniacid = :uniacid", array(":module" => MODULE, ":uniacid" => $_W["uniacid"]));
		return unserialize($cfg);
	}
	public static function gettoken()
	{
		global $_W;
		$outhData = commonGetData::getouthData();
		$appId = $outhData["mh_appid"];
		$appSecretKey = $outhData["mh_appkey"];
		$randStr = time();
		$link = $_SERVER["HTTP_HOST"];
		$preSign = "app_id=" . $appId . "app_secret_key=" . $appSecretKey . "rand_str=" . $randStr;
		$sign = md5($preSign);
		$query = "app_id=" . $appId . "&rand_str=" . $randStr . "&sign=" . $sign . "&link=" . $link . "&name=" . $_W["uniaccount"]["name"];
		$url = self::mihuaUrl() . "auth?" . $query;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
		curl_setopt($ch, CURLOPT_HEADER, false);
		$content = curl_exec($ch);
		curl_close($ch);
		if (empty($content) && $content == '') {
			return '';
		} else {
			$json_content = json_decode($content);
			if ($json_content->code == 0) {
				setcookie("mihua_token", $json_content->data, time() + 3600 * 2);
				return $json_content->data;
			} else {
				return '';
			}
		}
	}
	public static function mihuatoken()
	{
		global $_W;
		$sesstion_token = self::gettoken();
		if ($sesstion_token == '') {
			$sesstion_token = self::gettoken();
			if ($sesstion_token == '') {
				if ($_W["isajax"]) {
					die("<script>window.location.href='http://s.we7.cc/module-2798.html'</script>");
				} else {
					message("<a href=\"http://s.we7.cc/module-2798.html\">很抱歉，该域名未授权，请联系开发者处理！</a>");
				}
			}
		}
		return $sesstion_token;
	}
}