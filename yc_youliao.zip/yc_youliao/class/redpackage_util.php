<?php

/**
 * Created by PhpStorm.
 * User: Think
 * Date: 2017/10/30
 * Time: 9:12
 */
class Redpackage_util
{

    static public function sendRedpackage(){

    }

}