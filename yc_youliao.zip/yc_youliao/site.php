<?php
defined('IN_IA') or die('Access Denied');
require IA_ROOT . '/addons/yc_youliao/class/defineData.php';
require IA_ROOT . '/addons/yc_youliao/class/func.php';
require IA_ROOT . '/addons/yc_youliao/class/autoLoad.php';
require IA_ROOT . '/addons/yc_youliao/class/webCommon.php';
require IA_ROOT . '/addons/yc_youliao/class/commonGetData.php';
require IA_ROOT . '/addons/yc_youliao/class/util.php';
require IA_ROOT . '/addons/yc_youliao/class/reqInfo.php';
require IA_ROOT . '/addons/yc_youliao/class/core.php';
require IA_ROOT . '/addons/yc_youliao/class/near_merchant.php';
require IA_ROOT . '/addons/yc_youliao/class/function_common.class.php';
require IA_ROOT . '/addons/yc_youliao/model/Info.php';
require IA_ROOT . '/addons/yc_youliao/model/Admin.php';
require IA_ROOT . '/addons/yc_youliao/model/Adv.php';
require IA_ROOT . '/addons/yc_youliao/model/City.php';
require IA_ROOT . '/addons/yc_youliao/model/Shop_pro.php';
require IA_ROOT . '/addons/yc_youliao/model/Goods.php';
require IA_ROOT . '/addons/yc_youliao/model/Discount.php';
require IA_ROOT . '/addons/yc_youliao/model/Group.php';
require IA_ROOT . '/addons/yc_youliao/model/Member.php';
require IA_ROOT . '/addons/yc_youliao/model/Order.php';
require IA_ROOT . '/addons/yc_youliao/model/Message.php';
require IA_ROOT . '/addons/yc_youliao/model/Queue.php';
require IA_ROOT . '/addons/yc_youliao/model/Qr_code.php';
require IA_ROOT . '/addons/yc_youliao/model/PayResult.php';
require IA_ROOT . '/addons/yc_youliao/model/Msg.php';
require IA_ROOT . '/addons/yc_youliao/model/Redpackage.php';
include_once IA_ROOT . "/framework/library/qrcode/phpqrcode.php";
class yc_youliaoModuleSite extends WeModuleSite
{
	public function __call($function_name, $args)
	{
		if (strstr($function_name, 'doWeb')) {
			$fname = str_ireplace('doWeb', '', $function_name);
			$this->__web($fname);
		} else {
			if (strstr($function_name, 'doMobile')) {
				$fname = str_ireplace('doMobile', '', $function_name);
				$this->__mobileNew($fname);
			}
		}
	}
	public function __web($module)
	{
		global $_GPC, $_W;
		session_start();
		load()->func("file");
		load()->func("tpl");
		load()->model("mc");
		$module = lcfirst($module);
		if (!file_exists(yc_youliao . 'module/web/' . $module . '.php') && !file_exists(SQ . 'module/web/shop/' . $module . '.php')) {
			include $this->template("error");
			die;
		} else {
			$adminData = Admin::getAdminByPassword();
			if ($_W['username'] == 'mihua_sq_wq_admin' && strpos($module, 'shop_') === false && empty($adminData)) {
				$content = '您没有访问权限';
				include $this->template("error");
				die;
			} else {
				if (strpos($module, 'shop_') !== false) {
					$shop_id = getShop_id();
					$shop = Shop::getShopInfo($shop_id);
					setShop_name($shop['shop_name']);
					setShop_logo($shop['logo']);
					setIs_discount($shop['is_discount']);
					setIs_group($shop['is_group']);
					setIs_time($shop['is_time']);
					setIs_hot($shop['is_hot']);
					require yc_youliao . 'module/web/shop/' . $module . '.php';
				} else {
					if ($module == 'setting' || $module == 'tpl' || $module == 'city' || $module == 'area') {
						$type = '1';
					} else {
						if ($module == 'adv' || $module == 'msg') {
							$type = '2';
						} else {
							if ($module == 'channel' || $module == 'info' || $module == 'gather') {
								$type = '3';
							} else {
								if ($module == 'shopcate' || $module == 'shop' || $module == 'shop_info') {
									$type = '4';
								} else {
									if ($module == 'account' && $_GPC['op'] != 'display') {
										$type = '5';
									} else {
										if ($module == 'account' && $_GPC['op'] == 'display') {
											$type = '6';
										} else {
											if ($module == 'red') {
												$type = '7';
											} else {
												if ($module == 'ring') {
													$type = '8';
												} else {
													if ($module == 'member') {
														$type = '9';
													} else {
														if ($module == 'admin' || $module == 'uniacidList') {
															$type = '10';
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					self::checkAdminType($type, $adminData);
					require yc_youliao . 'module/web/' . $module . '.php';
				}
			}
		}
	}
	public function __mobileNew($module)
	{
		global $_GPC, $_W;
		load()->func("file");
		load()->func("tpl");
		load()->model("mc");
		$module = lcfirst($module);
		session_start();
		if (!file_exists(yc_youliao . 'module/mobile/' . $module . '.php')) {
			include $this->template("../error");
			die;
		} else {
			require yc_youliao . 'module/mobile/' . $module . '.php';
		}
	}
	public function doMobilePay()
	{
		global $_W, $_GPC;
		$type = trim($_GPC['type']);
		if ($type != 'message' && $type != 'merchant' && $type != 'zhiding' && $type != 'good') {
			message('支付类型不正确！');
		}
		$orid = trim($_GPC['orid']);
		if ($type == 'merchant') {
			$order = pdo_fetch('SELECT * FROM ' . tablename(RENEW) . " WHERE weid = {$_W['uniacid']} AND id = '{$orid}' AND status = 0");
			$ordertitle = '商家入驻支付';
			$ordersn = $order['ordersn'];
		} else {
			if ($type == 'message') {
				$ordertitle = '';
				$zdid = intval($_GPC['zdid']);
				if ($zdid > 0) {
					$zdorder = pdo_fetch('SELECT * FROM ' . tablename(ZDORDER) . " WHERE weid = {$_W['uniacid']} AND id = '{$zdid}' AND status = 0");
					$ordertitle .= '置顶';
					$order['ordersn'] = $zdorder['ordersn'];
				}
				if ($orid) {
					$infoorder = pdo_fetch('SELECT * FROM ' . tablename(INFOORDER) . " WHERE weid = {$_W['uniacid']} AND id = '{$orid}' AND status = 0");
					$ordertitle .= '发布';
					$order['ordersn'] = $infoorder['ordersn'];
				}
				$ordertitle .= '信息支付';
				$order['price'] = $zdorder['price'] + $infoorder['price'];
				$ordersn = $order['ordersn'];
			} else {
				if ($type == 'zhiding') {
					$order = pdo_fetch('SELECT * FROM ' . tablename(ZDORDER) . " WHERE weid = {$_W['uniacid']} AND id = '{$orid}' AND status = 0");
					$ordertitle = '置顶信息支付';
					$ordersn = $order['ordersn'];
				} else {
					if ($type == 'good') {
						$order = pdo_fetch('SELECT * FROM ' . tablename(ORDER) . " WHERE uniacid = {$_W['uniacid']} AND id = '{$orid}' AND status = 0");
						$ordertitle = $_GPC['name'];
						$ordersn = $order['ordersn'];
						$ordersn = 'orsn' . $ordersn;
					}
				}
			}
		}
		if (empty($order)) {
			message('该订单不能支付！');
		}
		$mihua_token = reqInfo::mihuatoken();
		$tid = reqInfo::gettokenOrsn($ordersn, $mihua_token);
		$fee = $order['price'];
		$params = array('tid' => $tid, 'title' => $ordertitle, 'fee' => $fee, 'user' => $_W['openid']);
		commonGetData::insertlog($params);
		if ($fee <= 0) {
			pdo_update('core_paylog', array('tid' => 'orsn' . $order['ordersn'], 'encrypt_code' => $params['tid'], 'status' => 1), array('module' => 'yc_youliao', 'tid' => $params['tid']));
			$this->payResult(array("tid" => $tid, "from" => "return", "type" => "credit2", "result" => "success", $params["user"] = $order["openid"], "fee" => $order["price"]));
		}
		$this->pay($params);
		die;
	}
	public function domobiletest()
	{
		global $_GPC, $_W;
		$redpackage = new Redpackage();
		$test = $redpackage->sendHB($_GPC["total"], $_GPC["num"], 1);
		print_r($test);
	}
	protected function pay($params = array(), $mine = array())
	{
		global $_GPC, $_W;
		$cfg = $this->module["config"];
		if ($cfg['islanniu_hsyunfu'] == 1) {
			if (!empty($_GPC['sign'])) {
				$_openid = trim($_GPC['openid']);
				$_appid = trim($_GPC['appid']);
				$params['_payopenid'] = $_openid;
				$params['_appid'] = $_appid;
			} else {
				$callback = $_W['siteurl'];
				$url = 'https://wex.hsyunfu.com/oauth/wex/login.do?ret_url=' . urlencode($callback);
				header('Location: ' . $url);
				die;
			}
			load()->model("activity");
			load()->model("module");
			activity_coupon_type_init();
			if (!$this->inMobile) {
				message('支付功能只能在手机上使用', '', '');
			}
		}
		$params['module'] = $this->module["name"];
		if ($params['fee'] <= 0) {
			$pars = array();
			$pars['from'] = 'return';
			$pars['result'] = 'success';
			$pars['type'] = '';
			$pars['tid'] = $params['tid'];
			$site = WeUtility::createModuleSite($params["module"]);
			$method = 'payResult';
			if (method_exists($site, $method)) {
				die($site->{$method}($pars));
			}
		}
		$log = pdo_get('core_paylog', array('uniacid' => $_W['uniacid'], 'module' => $params['module'], 'tid' => $params['tid']));
		if (empty($log)) {
			$log = array('uniacid' => $_W['uniacid'], 'acid' => $_W['acid'], 'openid' => $_W['member']['uid'], 'module' => $this->module["name"], "tid" => $params["tid"], "fee" => $params["fee"], "card_fee" => $params["fee"], "status" => "0", "is_usecard" => "0");
			pdo_insert('core_paylog', $log);
		}
		if ($log['status'] == '1') {
			message('这个订单已经支付成功, 不需要重复支付.', '', 'info');
		}
		$setting = uni_setting($_W['uniacid'], array('payment', 'creditbehaviors'));
		if (!is_array($setting['payment'])) {
			message('没有有效的支付方式, 请联系网站管理员.', '', 'error');
		}
		$pay = $setting['payment'];
		$we7_coupon_info = module_fetch('we7_coupon');
		if (!empty($we7_coupon_info) && $cfg['islanniu_hsyunfu'] == 1) {
			$cards = activity_paycenter_coupon_available();
			if (!empty($cards)) {
				foreach ($cards as $key => &$val) {
					if ($val['type'] == '1') {
						$val['discount_cn'] = sprintf('%.2f', $params['fee'] * (1 - $val['extra']['discount'] * 0.01));
						$coupon[$key] = $val;
					} else {
						$val['discount_cn'] = sprintf('%.2f', $val['extra']['reduce_cost'] * 0.01);
						$token[$key] = $val;
						if ($log['fee'] < $val['extra']['least_cost'] * 0.01) {
							unset($token[$key]);
						}
					}
					unset($val['icon']);
					unset($val['description']);
				}
			}
			$cards_str = json_encode($cards);
		}
		if (empty($_W['member']['uid'])) {
			$pay['credit']['switch'] = false;
		}
		if ($params['module'] == 'paycenter') {
			$pay['delivery']['switch'] = false;
			$pay['line']['switch'] = false;
		}
		if (!empty($pay['credit']['switch'])) {
			$credtis = mc_credit_fetch($_W['member']['uid']);
		}
		$you = 0;
		include $this->template("common/paycenter");
	}
	public function payResult($params)
	{
		global $_W;
		$_W['siteroot'] = str_replace('addons/lanniu_hsyunfu', '', $_W['siteroot']);
		$PayResult = new PayResult();
		if (empty($_W['uniacid'])) {
			$_W['uniacid'] = $params['uniacid'];
		}
		$logData = Util::getSingelDataInSingleTable("core_paylog", array("module" => "yc_youliao", "encrypt_code" => $params["tid"]));
		if ($params['result'] == 'success' && $params['from'] == 'notify') {
			if (empty($logData)) {
				$token = reqInfo::gettoken();
				if ($token == '') {
					return;
				}
				$pay_orsn = reqInfo::gettokenNum($params["tid"], $token);
				if ($pay_orsn == '') {
					return;
				}
				$id = $pay_orsn;
				$logData = $PayResult->checkReq($params, $id, "1");
				if ($logData == 0) {
					return;
				}
				$params['tid'] = $id;
			}
			$ordersnlen = strlen($id);
			$paydetail = $logData['tag'];
			$logtag = unserialize($logData['tag']);
			if (strstr($id, 'orsn')) {
				$PayResult->payresult_order($params);
			} else {
				if (strstr($id, 'ye')) {
					$PayResult->payresult_ye($params);
				} else {
					if (strstr($id, 'dis')) {
						$PayResult->payresult_dis($params);
					} else {
						if (strstr($id, 'redpackage')) {
							$cfg = $this->module["config"];
							$PayResult->payresult_redpackage($params, $cfg["redMsg"], $cfg["redMsg_num"], $cfg["redMsgUser"]);
						} else {
							if (strstr($id, 'shang')) {
								$PayResult->payresult_shang($params);
							} else {
								if (strstr($id, 'renew')) {
									$PayResult->payresult_renew($params);
								} else {
									if ($ordersnlen == 15) {
										$PayResult->payresult_info($params, $paydetail, $logtag);
									} else {
										if ($ordersnlen == 20) {
											$PayResult->payresult_zd($params, $paydetail, $logtag);
										}
									}
								}
							}
						}
					}
				}
			}
		}
		if ($params['from'] == 'return') {
			if ($params['result'] == 'success' || $params['type'] == 'delivery') {
				$logData = $PayResult->checkReq($params);
				if ($logData['encrypt_code'] == '') {
					$token = reqInfo::gettoken();
					if ($token == '') {
						return;
					}
					$pay_orsn = reqInfo::gettokenNum($params["tid"], $token);
					if ($pay_orsn == '') {
						return;
					}
					$id = $pay_orsn;
					$params['tid'] = $id;
				}
				$price = $params['fee'];
				$id = $params['tid'];
				$ordersnlen = strlen($id);
				$paydetail = $logData['tag'];
				$logtag = unserialize($logData['tag']);
				if (strstr($id, 'orsn')) {
					$PayResult->payresult_order($params);
					$ordersn = str_ireplace('orsn', '', $id);
					$order = Util::getSingelDataInSingleTable(ORDER, array("ordersn" => $ordersn, "uniacid" => $_W["uniacid"]));
					if ($price == 0) {
						$info = '订单提交成功！';
					} else {
						$info = '订单支付成功！';
					}
					$info_url = Util::createModuleUrl("order", array("op" => "detail", "id" => $order["id"]));
				} else {
					if (strstr($id, 'ye')) {
						$PayResult->payresult_ye($params);
						$info = '余额充值成功！';
						$info_url = Util::createModuleUrl("balance", array("op" => "record", "status" => "1"));
					} else {
						if (strstr($id, 'dis')) {
							$dis_id = str_ireplace('dis', '', $id);
							$order = Util::getSingelDataInSingleTable(DISCOUNT_RE, array("id" => $dis_id, "uniacid" => $_W["uniacid"]));
							$PayResult->payresult_dis($params);
							$info = '优惠买单支付成功！';
							$info_url = Util::createModuleUrl("user", array("op" => "mydiscount", "id" => $dis_id));
						} else {
							if (strstr($id, 'renew')) {
								$PayResult->payresult_renew($params);
								$info = '商户缴费成功！';
								$id = str_replace('renew', '', $params['tid']);
								$result = pdo_fetch('select * from ' . tablename(RENEW) . " where ordersn={$id}  and
		uniacid={$_W['uniacid']}    and status=0");
								$info_url = Util::createModuleUrl("shop_admin", array("shop_id" => $result["shop_id"]));
							} else {
								if (strstr($id, 'redpackage')) {
									$info = ' 发布抢红包支付成功！';
									$cfg = $this->module["config"];
									$PayResult->payresult_redpackage($params, $cfg["redMsg"], $cfg["redMsg_num"], $cfg["redMsgUser"]);
									$red_id = str_ireplace('redpackage', '', $params['tid']);
									$info_url = Util::createModuleUrl("redpackage", array("op" => "showredpackage", "id" => $red_id));
								} else {
									if (strstr($id, 'shang')) {
										$info = '打赏支付成功！';
										$PayResult->payresult_shang($params);
										$order_sn = str_ireplace('shang', '', $params['tid']);
										$cash_data = Util::getSingelDataInSingleTable(CASH, array("cash_ordersn" => $order_sn));
										if ($cash_data['cash_type'] == 2) {
											$do = 'ring';
											$op = 'detail';
										} else {
											if ($cash_data['cash_type'] == 3) {
												$do = 'detail';
												$op = 'display';
											}
										}
										$info_url = Util::createModuleUrl($do, array("op" => $op, "id" => $cash_data["type_id"]));
									} else {
										if ($ordersnlen == 15) {
											$info_id = $PayResult->payresult_info($params, $paydetail, $logtag);
											$info = ' 发布信息支付成功！';
											$info_url = Util::createModuleUrl("mylocal");
										} else {
											if ($ordersnlen == 20) {
												$info_id = $PayResult->payresult_zd($params, $paydetail, $logtag);
												$info = ' 置顶信息支付成功！';
												$info_url = Util::createModuleUrl("mylocal");
											}
										}
									}
								}
							}
						}
					}
				}
			} else {
				if (strstr($id, 'orsn')) {
					$info = '订单支付失败！';
					$info_url = $this->createMobileUrl("order", array("status" => 0));
				} else {
					if (strstr($id, 'dis')) {
						$info = '优惠买单失败！';
						$info2 = '重新买单';
						$info_url = $this->createMobileUrl("shop", array("shop_id" => $params["shop_id"], "op" => "discount"));
					} else {
						if (strstr($id, 'redpackage')) {
							$info = '发布抢红包支付失败！';
							$info_url = $this->createMobileUrl("redpackage");
						} else {
							if ($ordersnlen == 15) {
								$info = '发布信息支付失败！';
								$info2 = '重新发布';
								$info_url = $this->createMobileUrl("mylocal");
							} else {
								if ($ordersnlen == 20) {
									$info = '置顶信息支付失败！';
									$info2 = '重新置顶';
									$info_url = $this->createMobileUrl("mylocal", array("status" => "1"));
								}
							}
						}
					}
				}
			}
		}
		$title = '账单详情';
		include $this->template("../mobile/payinfo");
		die;
	}
	function message($msg, $redirect = '', $type = '', $isapp = '')
	{
		global $_W, $_GPC;
		if ($redirect == 'refresh') {
			$redirect = $_W['script_name'] . '?' . $_SERVER['QUERY_STRING'];
		}
		if ($redirect == 'referer') {
			$redirect = referer();
		}
		if ($redirect == '') {
			$type = in_array($type, array('success', 'error', 'info', 'warning', 'ajax', 'sql')) ? $type : 'info';
		} else {
			$type = in_array($type, array('success', 'error', 'info', 'warning', 'ajax', 'sql')) ? $type : 'success';
		}
		if ($_W['isajax'] || !empty($_GET['isajax']) || $type == 'ajax') {
			if ($type != 'ajax' && !empty($_GPC['target'])) {
				die('
<script type="text/javascript">
parent.require([\'jquery\', \'util\'], function($, util){
	var url = ' . (!empty($redirect) ? 'parent.location.href' : '\'\'') . ';
	var modalobj = util.message(\'' . $msg . '\', \'\', \'' . $type . '\');
	if (url) {
		modalobj.on(\'hide.bs.modal\', function(){$(\'.modal\').each(function(){if($(this).attr(\'id\') != \'modal-message\') {$(this).modal(\'hide\');}});top.location.reload()});
	}
});
</script>');
			} else {
				$vars = array();
				$vars['message'] = $msg;
				$vars['redirect'] = $redirect;
				$vars['type'] = $type;
				die(json_encode($vars));
			}
		}
		if (empty($msg) && !empty($redirect)) {
			header('location: ' . $redirect);
		}
		$label = $type;
		if ($type == 'error') {
			$label = 'danger';
		}
		if ($type == 'ajax' || $type == 'sql') {
			$label = 'warning';
		}
		if ($isapp == '1') {
			$template = '../mobile/common/message';
		} else {
			$template = 'web/message';
		}
		include $this->template($template);
		die;
	}
	public function isMobile($mobile)
	{
		if (!is_numeric($mobile)) {
			return false;
		}
		return preg_match('#^13[\\d]{9}$|^14[5,7]{1}\\d{8}$|^15[^4]{1}\\d{8}$|^17[\\d]{9}$|^18[\\d]{9}$#', $mobile) ? true : false;
	}
	public function isCreditNo($vStr)
	{
		$vCity = array('11', '12', '13', '14', '15', '21', '22', '23', '31', '32', '33', '34', '35', '36', '37', '41', '42', '43', '44', '45', '46', '50', '51', '52', '53', '54', '61', '62', '63', '64', '65', '71', '81', '82', '91');
		if (!preg_match('/^([\\d]{17}[xX\\d]|[\\d]{15})$/', $vStr)) {
			return false;
		}
		if (!in_array(substr($vStr, 0, 2), $vCity)) {
			return false;
		}
		$vStr = preg_replace('/[xX]$/i', 'a', $vStr);
		$vLength = strlen($vStr);
		if ($vLength == 18) {
			$vBirthday = substr($vStr, 6, 4) . '-' . substr($vStr, 10, 2) . '-' . substr($vStr, 12, 2);
		} else {
			$vBirthday = '19' . substr($vStr, 6, 2) . '-' . substr($vStr, 8, 2) . '-' . substr($vStr, 10, 2);
		}
		if (date('Y-m-d', strtotime($vBirthday)) != $vBirthday) {
			return false;
		}
		if (!($vLength == 18)) {
			cgu69:
			return true;
		} else {
			$vSum = 0;
			$i = 17;
			jxPH1:
			if ($i < 0) {
				if (!($vSum % 11 != 1)) {
					goto cgu69;
				}
				return false;
				goto cgu69;
			}
			$vSubStr = substr($vStr, 17 - $i, 1);
			$vSum += pow(2, $i) % 11 * ($vSubStr == 'a' ? 10 : intval($vSubStr, 11));
			$i--;
			goto jxPH1;
		}
	}
	public function getcookieCity()
	{
		$codition = '';
		$city_id = intval($_COOKIE['city_id']);
		if ($city_id) {
			$codition = ' and s.city_id =' . $city_id;
		}
		return $codition;
	}
	public function joinArea()
	{
		$codition = ' left join ' . tablename(AREA) . ' a on a.area_id=s.area_id ';
		return $codition;
	}
	public function getArea()
	{
		global $_W;
		$city_name = $this->getCity_name();
		$codition = $this->getCityId($city_name);
		$list = pdo_fetchall(' SELECT * FROM ' . tablename(AREA) . " WHERE  uniacid = '{$_W['uniacid']}' {$codition} and (parent_id =0 or parent_id is null) ORDER BY  orderby asc");
		return $list;
	}
	public function getBusiness()
	{
		global $_W;
		$city_name = $this->getCity_name();
		$codition = $this->getCityId($city_name);
		$list = pdo_fetchall(' SELECT * FROM ' . tablename(AREA) . " WHERE  uniacid = '{$_W['uniacid']}' {$codition} and parent_id >0  ORDER BY  orderby asc");
		return $list;
	}
	public function getOpenid()
	{
		global $_W;
		return $_W['openid'];
	}
	public function getCredit1()
	{
		global $_W;
		$fans = mc_fetch($_W['openid']);
		return intval($fans['credit1']);
	}
	public function getUid()
	{
		load()->model("mc");
		return mc_openid2uid('getOpenid');
	}
	public function getLng()
	{
		$lng = $_COOKIE['lng'];
		return $lng;
	}
	public function getLat()
	{
		$lat = $_COOKIE['lat'];
		return $lat;
	}
	public function getReqLng()
	{
		$lng = $_COOKIE['reqlng'];
		return $lng;
	}
	public function getReqLat()
	{
		$lat = $_COOKIE['reqlat'];
		return $lat;
	}
	public function getAddress()
	{
		$data = $_COOKIE['address'];
		return $data;
	}
	public function getFormatted_address()
	{
		$data = $_COOKIE['formatted_address'];
		return $data;
	}
	public function getLactionflag()
	{
		$data = $_COOKIE['lactionflag'];
		return $data;
	}
	function getLaction_flag()
	{
		return $_SESSION['lactionflag'] ? $_SESSION['lactionflag'] : 0;
	}
	public function getKeyword()
	{
		global $_GPC;
		$keyword = '';
		if (!empty($_GPC['keyword'])) {
			$keyword = trim($_GPC['keyword']);
		}
		return $keyword;
	}
	public function getStarttime()
	{
		global $_GPC;
		$starttime = '';
		if (!empty($_GPC['starttime'])) {
			$starttime = strtotime($_GPC['starttime']);
		}
		return $starttime;
	}
	public function getEndtime()
	{
		global $_GPC;
		$endtime = '';
		if (!empty($_GPC['endtime'])) {
			$endtime = strtotime($_GPC['starttime']);
		}
		return $endtime;
	}
	public function getWebPage()
	{
		$page = reqInfo::pageIndex();
		return $page;
	}
	public function pageIndex()
	{
		$page = reqInfo::pageIndex();
		return $page;
	}
	public function getWebNum()
	{
		$num = reqInfo::num();
		return $num;
	}
	public function getPage()
	{
		$page = reqInfo::page();
		return $page;
	}
	public function getNum()
	{
		$num = reqInfo::num();
		return $num;
	}
	public function messageresult($str, $url, $result = 0, $status = "error")
	{
		global $_GPC;
		if ($_GPC['isajax'] == '1') {
			die(json_encode(array('result' => $result, 'str' => $str)));
			die;
		} else {
			message($str, $url, $status);
			die;
		}
	}
	public function getCity_id()
	{
		$city_id = intval($_COOKIE['city_id']);
		return $city_id;
	}
	public function getAdmin_city_id()
	{
		$city_id = intval($_COOKIE['admin_city_id']);
		return $city_id;
	}
	public function getAdmin_city_name()
	{
		$city_id = intval($_COOKIE['admin_city_id']);
		if ($city_id > 0) {
			$where['city_id'] = $city_id;
			$city = util::getSingelDataInSingleTable(CITY, $where);
			$city_name = $city['name'];
			$str2 = '市';
			if (strrchr($city_name, $str2) == $str2) {
				return $city_name;
			} else {
				return $city_name . $str2;
			}
		}
	}
	public function getArea_name()
	{
		$area_name = $_COOKIE['area_name'];
		return $area_name;
	}
	public function getProvince()
	{
		$data = $_COOKIE['province'];
		return $data;
	}
	public function getCity_name()
	{
		$city_name = $_COOKIE['city_name'];
		if (strpos($city_name, '市') !== false) {
			$city_name = str_replace('市', '', $city_name);
		}
		return $city_name;
	}
	public function getDistrict()
	{
		$district = $_COOKIE['district'];
		return $district;
	}
	public function showMsgNum()
	{
		$cfg = $this->module["config"];
		$data = ReqInfo::msgNum($cfg);
		return $data;
	}
	public function checkBlack()
	{
		global $_W;
		$openid = $this->getOpenid();
		$userinfo = Member::getMemberByopenid($openid);
		$black = Member::getBlack($userinfo["id"]);
		if (!empty($black)) {
			if ($_W['isajax']) {
				$resArr['error'] = 1;
				$resArr['message'] = '很抱歉，您已被移入黑名单！';
				echo json_encode($resArr);
				die;
			} else {
				message('很抱歉，您已被移入黑名单');
			}
		}
	}
	public function info_condition()
	{
		$info_condition = '';
		$city = $this->getCity_name();
		$cfg = $this->module["config"];
		$cityLimit = intval($cfg['issamecity']);
		if ($city && $cityLimit == 0) {
			$info_condition .= ' and city like \'' . $city . '%\' ';
		}
		return $info_condition;
	}
	public function mapreq()
	{
		$cfg = $this->module["config"];
		$data = ReqInfo::mapReq($cfg);
		return $data;
	}
	public function mapUrl()
	{
		$cfg = $this->module["config"];
		$data = ReqInfo::mapUrl($cfg);
		return $data;
	}
	public function chagexy()
	{
		$cfg = $this->module["config"];
		$data = ReqInfo::chagexy($cfg);
		return $data;
	}
	public function weatherreq()
	{
		$cfg = $this->module["config"];
		$data = ReqInfo::weatherreq($cfg);
		return $data;
	}
	public function getWeather($city_name)
	{
		$weatherurl = $this->weatherreq();
		$weatherdata = util::getWeather($weatherurl, $city_name);
		$weather2 = json_decode($weatherdata, 1);
		if ($weather2['status'] == '1002') {
			$weatherdata = util::getWeather($weatherurl, $_COOKIE["district"]);
		}
		return $weatherdata;
	}
	public function checkAdmin($openid = '')
	{
		if ($openid) {
			$where['openid'] = $openid;
		} else {
			$where['openid'] = $this->getOpenid();
		}
		$where['status'] = 0;
		$a_data = util::getSingelDataInSingleTable(ADMIN, $where, "admin_id,passport,type");
		$a_data = Member::getAvName($a_data);
		return $a_data;
	}
	public function isshop_admin()
	{
		$admin_where['openid'] = $this->getOpenid();
		$admin_where['status'] = 0;
		$isshop_admin = util::getSingelDataInSingleTable(SHOP_ADMIN, $admin_where);
		$isshop_admin = Member::getAvName($isshop_admin);
		return $isshop_admin;
	}
	public function getCustomerById($shop_id)
	{
		$admin_where['shop_id'] = intval($shop_id);
		$admin_where['customer'] = 1;
		$isshop_admin = util::getAllDataBySingleTable(SHOP_ADMIN, $admin_where, "admin_id desc");
		return $isshop_admin;
	}
	public function rep_text($openid, $word)
	{
		global $_W;
		$acid = pdo_fetchcolumn('select acid from ' . tablename('account') . " where uniacid={$_W['uniacid']} ");
		load()->classs("weixin.account");
		$accObj = WeixinAccount::create($acid);
		$accObj->sendCustomNotice(array("touser" => $openid, "msgtype" => "text", "text" => array("content" => urlencode($word))));
	}
	function getmodulename($weid, $mid)
	{
		$moduleres = pdo_fetch('SELECT name FROM ' . tablename(CHANNEL) . " WHERE weid = {$weid} AND id = {$mid}");
		return $moduleres['name'];
	}
	function getShopQr()
	{
		global $_W, $_GPC;
		$shop_id = getShop_id();
		if ($shop_id == 0) {
			$shop_id = $_GPC['shop_id'];
		}
		$qr_code = util::getSingelDataInSingleTable(SHOP, array("shop_id" => $shop_id), "qr_code");
		if ($qr_code['qr_code']) {
			$qr_code = $qr_code['qr_code'];
		} else {
			$url = $_W['siteroot'] . "app/index.php?i={$_W['uniacid']}&c=entry&do=shop&shop_id={$shop_id}&m=yc_youliao&flag=scan";
			$qr_code = util::getURLQR($url, "shop_" . $shop_id);
			pdo_update(SHOP, array('qr_code' => $qr_code), array('shop_id' => $shop_id));
		}
		return $qr_code;
	}
	function isShang()
	{
		$cfg = $this->module["config"];
		return intval($cfg['isshang']);
	}
	function isRedpacket()
	{
		$cfg = $this->module["config"];
		return intval($cfg['isredpacket']);
	}
	function getCreateShopQr($shop_id)
	{
		$barcode = array('action_name' => 'QR_SCENE', 'action_info' => array('scene' => array('scene_id' => $shop_id)));
		load()->classs("account");
		$this->account = WeAccount::create($GLOBALS["_W"]["acid"]);
		$weixin_qr = $this->account->barCodeCreateFixed($barcode);
		$qrfile = 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=' . $weixin_qr['ticket'];
		return $qrfile;
	}
	public function getCfg($name)
	{
		$cfg = $this->module["config"];
		return $cfg[$name];
	}
	public function getSwitch_base()
	{
		$res = $this->getCfg("switch_base");
		$switch_base = intval($res);
		return $switch_base;
	}
	public static function checkAdminType($type, $adminData)
	{
		if (empty($type)) {
			return;
		}
		$res = Admin::checkAdminType($type, $adminData);
		if (!$res) {
			message('很抱歉，您没有此项功能权限', '', 'success');
		}
	}
}